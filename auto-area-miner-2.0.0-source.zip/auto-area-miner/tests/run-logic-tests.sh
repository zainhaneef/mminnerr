#!/bin/sh
# Offline tests (no Minecraft needed): pathfinding, aim maths, camera smoothing, steering, layer planning,
# target selection, progress counting, and headless simulations of whole quarry runs.
# Needs a JDK 21 (javac). Run from the project root:  sh tests/run-logic-tests.sh
S=src/main/java/com/areaminer
rm -rf tests/out && mkdir -p tests/out
javac -d tests/out $(find tests/stubs -name "*.java") $S/area/*.java $S/pathfinding/LayerPlan.java \
  $S/automation/Terrain.java $S/automation/Pathfinder.java $S/automation/AimMath.java \
  $S/automation/AimSmoother.java $S/automation/PathSteer.java \
  $S/mining/MiningStats.java $S/mining/TargetSelector.java $S/mining/MiningBrain.java \
  tests/src/LogicTests.java tests/src/SimTests.java \
  && java -cp tests/out LogicTests && java -cp tests/out SimTests
