package com.google.gson;
public class Gson {
    public String toJson(Object o) { return "{}"; }
    public <T> T fromJson(String s, Class<T> c) { return null; }
}
