@echo off
REM Offline tests (no Minecraft needed). Needs JDK 21 on PATH. Run from the project root.
set S=%CD%\src\main\java\com\areaminer
if exist tests\out rmdir /s /q tests\out
mkdir tests\out
dir /s /b tests\stubs\*.java > tests\files.txt
dir /s /b "%S%\area\*.java" >> tests\files.txt
echo %S%\pathfinding\LayerPlan.java>> tests\files.txt
echo %S%\automation\Terrain.java>> tests\files.txt
echo %S%\automation\Pathfinder.java>> tests\files.txt
echo %S%\automation\AimMath.java>> tests\files.txt
echo %S%\automation\AimSmoother.java>> tests\files.txt
echo %S%\automation\PathSteer.java>> tests\files.txt
echo %S%\mining\MiningStats.java>> tests\files.txt
echo %S%\mining\TargetSelector.java>> tests\files.txt
echo %S%\mining\MiningBrain.java>> tests\files.txt
echo %CD%\tests\src\LogicTests.java>> tests\files.txt
echo %CD%\tests\src\SimTests.java>> tests\files.txt
javac -d tests\out @tests\files.txt && java -cp tests\out LogicTests && java -cp tests\out SimTests
pause
