import com.areaminer.area.*;
import com.areaminer.automation.*;
import com.areaminer.mining.*;
import com.areaminer.pathfinding.LayerPlan;
import net.minecraft.util.math.BlockPos;

import java.util.*;

/**
 * Headless tests of the 2.0 decision logic. The Sim below plays the role of Minecraft: a block world,
 * a player that walks cell to cell, line-of-sight and reach checks, gravity, mining that removes
 * blocks. It drives the REAL LayerPlan, TargetSelector, MiningBrain, Pathfinder, AimSmoother and
 * PathSteer. It cannot test Minecraft physics, input, rendering or the real ray casts.
 */
public class BrainTests {
    static int passed = 0, failed = 0;

    static void check(String name, boolean ok) {
        if (ok) { passed++; System.out.println("PASS  " + name); }
        else { failed++; System.out.println("FAIL  " + name); }
    }

    // ------------------------------------------------------------------ simulator

    static final double EYE = 1.62, REACH = 4.15, STAND = 2.8;
    static final int MINE_TICKS = 4, WALK_TICKS = 4, STEP_TICKS = 6;

    static class Sim {
        final int W, H, G;
        final boolean[][][] solid;
        final Quarry q;
        QuarryModel model;
        MiningBrain brain;
        int[][] footprint;
        final LayerLike layerLike = null;
        int px, py, pz;
        long ticks, probes, searches, deferrals, loops;
        boolean finished;
        final Random rnd = new Random(42);
        final List<int[]> mined = new ArrayList<>();   // {layer, idx, ring}
        double jumpSum; int jumps; int targets;
        long clearedOffset;
        final LayerPlan.Order order;

        interface LayerLike { }

        Sim(int w, int h, int g, int qx, int qz, int qsx, int qsz, int layers, boolean uneven,
            int[][] fp, LayerPlan.Order order) {
            W = w; H = h; G = g;
            this.order = order;
            solid = new boolean[W][H][W];
            for (int x = 0; x < W; x++)
                for (int z = 0; z < W; z++) {
                    int top = G;
                    boolean inQ = x >= qx && x < qx + qsx && z >= qz && z < qz + qsz;
                    if (uneven && !inQ) top = G + Math.abs(((x / 3 + z / 4) % 4) - 2) - 1;
                    for (int y = 0; y <= top; y++) solid[x][y][z] = true;
                }
            q = new Quarry(new BlockPos(qx, G - layers + 1, qz), new BlockPos(qx + qsx - 1, G, qz + qsz - 1), "sim");
            footprint = fp;
            px = 2; pz = 2; py = surface(px, pz) + 1;
            rescan(0);
        }

        int surface(int x, int z) { int y = H - 1; while (y > 0 && !solid[x][y][z]) y--; return y; }

        void rescan(long offset) {
            model = new QuarryModel(q);
            for (int l = 0; l < model.layers.length; l++)
                for (int i = 0; i < model.layers[l].size(); i++)
                    model.layers[l].set(i, isSolid(q.cellX(i), q.yOfLayer(l), q.cellZ(i)) ? CellState.REMAINING : CellState.EMPTY);
            model.cleared = offset;
            brain = new MiningBrain(model, new MiningBrain.Params(64, 4, 3, false, order));
        }

        boolean inW(int x, int y, int z) { return x >= 0 && y >= 0 && z >= 0 && x < W && y < H && z < W; }
        boolean isSolid(int x, int y, int z) { return inW(x, y, z) && solid[x][y][z]; }

        final Terrain terrain = new Terrain() {
            public boolean passable(int x, int y, int z) { return inW(x, y, z) && !solid[x][y][z]; }
            public boolean solidFloor(int x, int y, int z) { return inW(x, y, z) && solid[x][y][z]; }
        };

        boolean visible(double ex, double ey, double ez, int tx, int ty, int tz) { return visible(ex, ey, ez, tx, ty, tz, REACH); }

        // like AimPlanner: the top face centre, or one of the four side face centres
        boolean visible(double ex, double ey, double ez, int tx, int ty, int tz, double maxDist) {
            double[][] pts = {{0.5, 0.98, 0.5}, {0.5, 0.6, 0.02}, {0.5, 0.6, 0.98}, {0.02, 0.6, 0.5}, {0.98, 0.6, 0.5}};
            for (double[] o : pts) if (visibleAt(ex, ey, ez, tx, ty, tz, tx + o[0], ty + o[1], tz + o[2], maxDist)) return true;
            return false;
        }

        boolean visibleAt(double ex, double ey, double ez, int tx, int ty, int tz, double ax, double ay, double az, double maxDist) {
            double dx = ax - ex, dy = ay - ey, dz = az - ez;
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len > maxDist) return false;
            int n = (int) Math.ceil(len / 0.05);
            for (int i = 0; i <= n; i++) {
                double t = (double) i / n;
                int cx = (int) Math.floor(ex + dx * t), cy = (int) Math.floor(ey + dy * t), cz = (int) Math.floor(ez + dz * t);
                if (cx == tx && cy == ty && cz == tz) return true;
                if (isSolid(cx, cy, cz)) return false;
            }
            return false;
        }

        Pathfinder.Goal goal(int tx, int ty, int tz) {
            return new Pathfinder.Goal() {
                public boolean allowed(int x, int y, int z) { return y >= ty; }
                public boolean reached(int x, int y, int z) {
                    return visible(x + 0.5, y + EYE, z + 0.5, tx, ty, tz, STAND);
                }
                public double estimate(int x, int y, int z) {
                    double dx = x + 0.5 - tx - 0.5, dy = y + EYE - ty - 0.5, dz = z + 0.5 - tz - 0.5;
                    return Math.max(0, Math.sqrt(dx * dx + dy * dy + dz * dz) - STAND);
                }
            };
        }

        double probe(int idx) {
            probes++;
            int x = q.cellX(idx), y = q.yOfLayer(brain.layer()), z = q.cellZ(idx);
            Pathfinder.Goal g = goal(x, y, z);
            if (canMine(x, y, z)) return 0;
            searches++;
            List<int[]> p = Pathfinder.find(terrain, px, py, pz, g, 3000);
            if (p == null) deferrals++;
            return p == null ? -1 : p.size() - 1;
        }

        boolean canMine(int x, int y, int z) { return visible(px + 0.5, py + EYE, pz + 0.5, x, y, z, REACH); }

        void gravity() { while (py > 0 && !solid[px][py - 1][pz]) py--; }

        void execute(int idx) {
            int x = q.cellX(idx), y = q.yOfLayer(brain.layer()), z = q.cellZ(idx);
            Pathfinder.Goal g = goal(x, y, z);
            if (!canMine(x, y, z)) {
                searches++;
                List<int[]> p = Pathfinder.find(terrain, px, py, pz, g, 3000);
                if (p == null) { brain.defer(idx); deferrals++; ticks++; return; }
                for (int i = 1; i < p.size(); i++) {
                    int[] n = p.get(i);
                    ticks += (n[1] != py) ? STEP_TICKS : WALK_TICKS;
                    px = n[0]; py = n[1]; pz = n[2];
                }
            }
            ticks += MINE_TICKS;
            for (int[] o : footprint) {
                int cx = x + o[0], cy = y + o[1], cz = z + o[2];
                if (q.contains(cx, cy, cz) && solid[cx][cy][cz] && model.stateAt(cx, cy, cz) == CellState.REMAINING) {
                    solid[cx][cy][cz] = false;
                    model.observe(cx, cy, cz, CellState.EMPTY);
                }
            }
            gravity();
            int last = mined.isEmpty() ? -1 : mined.get(mined.size() - 1)[1];
            if (last >= 0 && mined.get(mined.size() - 1)[0] == brain.layer()) {
                double dist = Math.hypot(q.cellX(idx) - q.cellX(last), q.cellZ(idx) - q.cellZ(last));
                jumpSum += dist;
                if (dist > 6.0) jumps++;
            }
            targets++;
            mined.add(new int[]{brain.layer(), idx, brain.ringOf(idx)});
            brain.targetDone(idx);
        }

        void iterate() {
            loops++;
            if (brain.layer() < 0) {
                if (!brain.enterNextLayer()) { finished = true; return; }
            }
            LayerData d = model.layers[brain.layer()];
            if (!brain.hasPlan()) { brain.planStep(footprint, 1_000_000); ticks++; return; }
            if (d.remaining == 0 && d.unknown == 0) {
                if (!brain.enterNextLayer()) finished = true;
                return;
            }
            MiningBrain.Pick pk = brain.pick(px - q.minX, pz - q.minZ, this::probe);
            switch (pk.kind) {
                case TARGET -> execute(pk.idx);
                case NEED_SINGLE_TOOL -> { footprint = new int[][]{{0, 0, 0}}; brain.invalidatePlan(); ticks++; }
                default -> ticks++;
            }
        }

        /** Runs for up to {@code budget} simulated ticks (or until done). */
        void run(long budget, Runnable events) {
            long end = ticks + budget;
            long guard = 0;
            while (!finished && ticks < end) {
                if (events != null) events.run();
                iterate();
                if (++guard > 5_000_000L) throw new IllegalStateException("simulation did not terminate");
            }
        }
    }

    static long ignoredCount(Sim s) {
        long n = 0;
        for (LayerData l : s.model.layers) for (int i = 0; i < l.size(); i++) if (l.get(i) == CellState.IGNORED) n++;
        return n;
    }

    static final int[][] SINGLE = {{0, 0, 0}};
    static int[][] square(int n) {
        int r = n / 2, i = 0;
        int[][] fp = new int[n * n][];
        for (int dz = -r; dz <= r; dz++) for (int dx = -r; dx <= r; dx++) fp[i++] = new int[]{dx, 0, dz};
        return fp;
    }

    static boolean layersMonotone(Sim s) {
        int prev = -1;
        for (int[] m : s.mined) { if (m[0] < prev) return false; prev = m[0]; }
        return true;
    }

    static double ringDecreaseFraction(Sim s) {
        int dec = 0, n = 0;
        for (int i = 1; i < s.mined.size(); i++) {
            if (s.mined.get(i)[0] != s.mined.get(i - 1)[0]) continue;
            n++;
            if (s.mined.get(i)[2] < s.mined.get(i - 1)[2]) dec++;
        }
        return n == 0 ? 0 : (double) dec / n;
    }

    // ------------------------------------------------------------------ simulation tests

    static void smallQuarry() {
        Sim s = new Sim(30, 20, 10, 10, 10, 5, 5, 5, false, SINGLE, LayerPlan.Order.CENTER_OUT);
        s.run(1_000_000, null);
        int centre = 2 + 2 * 5;
        check("sim 5x5x5: finishes", s.finished);
        check("sim 5x5x5: every block cleared exactly once (125)", s.model.remainingTotal() == 0 && s.model.cleared == 125);
        check("sim 5x5x5: first block mined is the geometric centre of the top layer",
                s.mined.get(0)[0] == 0 && s.mined.get(0)[1] == centre);
        check("sim 5x5x5: layers are completed top to bottom", layersMonotone(s));
        check("sim 5x5x5: rings expand outward (<=8% inward moves)", ringDecreaseFraction(s) <= 0.08);
        System.out.printf("      small: %d ticks, %d path searches, %d probes%n", s.ticks, s.searches, s.probes);
    }

    static void centreOutVsSerpentine() {
        Sim a = new Sim(30, 20, 10, 8, 8, 9, 9, 1, false, SINGLE, LayerPlan.Order.CENTER_OUT);
        a.run(1_000_000, null);
        Sim b = new Sim(30, 20, 10, 8, 8, 9, 9, 1, false, SINGLE, LayerPlan.Order.SERPENTINE);
        b.run(1_000_000, null);
        check("sim order: centre-out starts at the centre, serpentine starts at a corner",
                a.mined.get(0)[1] == 4 + 4 * 9 && b.mined.get(0)[1] == 0);
        check("sim order: both orders clear everything", a.model.remainingTotal() == 0 && b.model.remainingTotal() == 0);
    }

    static void largeQuarry() {
        Sim s = new Sim(90, 20, 12, 12, 12, 61, 61, 4, false, SINGLE, LayerPlan.Order.CENTER_OUT);
        long t0 = System.nanoTime();
        s.run(100_000_000L, null);
        double ms = (System.nanoTime() - t0) / 1e6;
        long total = 61L * 61 * 4;
        check("sim large 61x61x4: finishes with all " + total + " blocks cleared", s.finished && s.model.remainingTotal() == 0 && s.model.cleared == total);
        check("sim large: distant target hops are rare (<3% of targets)", s.jumps <= 0.03 * s.targets);
        check("sim large: mean distance between consecutive targets <= 2 cells", s.jumpSum / s.targets <= 2.0);
        check("sim large: layers top to bottom", layersMonotone(s));
        System.out.printf("      large: %d targets, %d ticks (%.1f ticks/block), %d path searches, mean hop %.2f, logic time %.0f ms%n",
                s.targets, s.ticks, (double) s.ticks / total, s.searches, s.jumpSum / s.targets, ms);
    }

    static void unevenTerrain() {
        Sim s = new Sim(40, 20, 10, 14, 14, 15, 15, 3, true, SINGLE, LayerPlan.Order.CENTER_OUT);
        s.run(10_000_000L, null);
        check("sim uneven terrain (+-1 steps around the quarry): finishes, all 675 cleared",
                s.finished && s.model.remainingTotal() == 0 && s.model.cleared == 675);
    }

    static void obstaclesAndUnreachable() {
        Sim s = new Sim(50, 20, 10, 14, 14, 21, 21, 3, false, SINGLE, LayerPlan.Order.CENTER_OUT);
        // a wall with a gap and pillars outside the quarry, in the player's way
        for (int z = 0; z < 20; z++) if (z != 9) for (int y = 11; y <= 12; y++) s.solid[8][y][z] = true;
        for (int i = 0; i < 6; i++) { s.solid[10][11][12 + i * 3] = true; s.solid[10][12][12 + i * 3] = true; }
        // three blocks sealed inside unbreakable blocks: nothing can ever reach them
        int[][] sealed = {{17, 8, 17}, {24, 9, 20}, {20, 8, 26}};
        s.rescan(0);
        for (int[] c : sealed) {
            int[][] nb = {{1, 0, 0}, {-1, 0, 0}, {0, 0, 1}, {0, 0, -1}, {0, 1, 0}, {0, -1, 0}};
            for (int[] d : nb) {
                int x = c[0] + d[0], y = c[1] + d[1], z = c[2] + d[2];
                s.solid[x][y][z] = true;
                if (s.q.contains(x, y, z)) s.model.layers[s.q.layerOfY(y)].set(s.q.cellIndex(x, z), CellState.IGNORED);
            }
        }
        s.run(50_000_000L, null);
        check("sim obstacles: finishes (no infinite loop)", s.finished);
        long skipped = s.model.skippedTotal();
        check("sim obstacles: the 3 sealed blocks end up skipped, not retried forever (skipped=" + skipped + ")", skipped == 3);
        check("sim obstacles: reachable blocks are all cleared (cleared + skipped = 1323)",
                s.model.remainingTotal() == 0 && s.model.cleared + skipped + ignoredCount(s) == 21L * 21 * 3);
        check("sim obstacles: some blocks were deferred before being skipped", s.deferrals > 0);
    }

    static void disappearingBlocks() {
        Sim s = new Sim(40, 20, 10, 12, 12, 11, 11, 4, false, SINGLE, LayerPlan.Order.CENTER_OUT);
        final long[] next = {40};
        s.run(50_000_000L, () -> {
            if (s.ticks < next[0] || s.brain.layer() < 0) return;
            next[0] = s.ticks + 40;
            // another agent removes a random remaining block, and sometimes a block is placed back
            for (int tries = 0; tries < 30; tries++) {
                int l = s.rnd.nextInt(s.model.layers.length), i = s.rnd.nextInt(s.model.layers[l].size());
                int x = s.q.cellX(i), y = s.q.yOfLayer(l), z = s.q.cellZ(i);
                if (s.solid[x][y][z]) { s.solid[x][y][z] = false; s.model.observe(x, y, z, CellState.EMPTY); break; }
            }
            if (s.rnd.nextInt(3) == 0 && s.brain.layer() >= 0) {
                int l = s.brain.layer(), i = s.rnd.nextInt(s.model.layers[l].size());
                int x = s.q.cellX(i), y = s.q.yOfLayer(l), z = s.q.cellZ(i);
                boolean standing = x == s.px && z == s.pz && (y == s.py || y == s.py + 1);
                if (!s.solid[x][y][z] && !standing && s.isSolid(x, y - 1, z)) { s.solid[x][y][z] = true; s.model.observe(x, y, z, CellState.REMAINING); }
            }
        });
        check("sim vanishing/appearing blocks: finishes with nothing left", s.finished && s.model.remainingTotal() == 0);
        check("sim vanishing blocks: each removal counted once (cleared <= 484 + placed blocks)", s.model.cleared >= 484);
    }

    static void pauseAndReload() {
        Sim s = new Sim(30, 20, 10, 10, 10, 7, 7, 4, false, SINGLE, LayerPlan.Order.CENTER_OUT);
        s.run(600, null);
        long before = s.model.cleared;
        check("sim pause: stopped part-way", !s.finished && before > 0 && before < 196);
        // world reload: runtime state is lost, the world keeps its blocks; progress offset is restored
        s.px = 2; s.pz = 2; s.py = s.surface(2, 2) + 1;
        s.rescan(before);
        s.run(10_000_000L, null);
        check("sim reload: run continues and finishes", s.finished && s.model.remainingTotal() == 0);
        check("sim reload: progress counter continues from the saved value (196 total)", s.model.cleared == 196);
    }

    static void longRunWithEvents() {
        Sim s = new Sim(70, 24, 14, 12, 12, 41, 41, 8, true, SINGLE, LayerPlan.Order.CENTER_OUT);
        final long[] next = {200};
        long t0 = System.nanoTime();
        s.run(500_000_000L, () -> {
            if (s.ticks < next[0] || s.brain.layer() < 0) return;
            next[0] = s.ticks + 200;
            int l = s.rnd.nextInt(s.model.layers.length), i = s.rnd.nextInt(s.model.layers[l].size());
            int x = s.q.cellX(i), y = s.q.yOfLayer(l), z = s.q.cellZ(i);
            if (s.solid[x][y][z]) { s.solid[x][y][z] = false; s.model.observe(x, y, z, CellState.EMPTY); }
        });
        double ms = (System.nanoTime() - t0) / 1e6;
        check("sim long run 41x41x8 (13k blocks) with events: finishes cleanly", s.finished && s.model.remainingTotal() == 0);
        check("sim long run: path searches stay bounded (<0.5 per block)", s.searches < 0.5 * 41 * 41 * 8);
        System.out.printf("      long: %d targets, %d ticks, %d searches, logic time %.0f ms%n", s.targets, s.ticks, s.searches, ms);
    }

    static void multiBlock() {
        Sim s = new Sim(50, 20, 10, 10, 10, 27, 27, 3, false, square(3), LayerPlan.Order.CENTER_OUT);
        s.run(10_000_000L, null);
        long total = 27L * 27 * 3;
        check("sim 3x3 ability: finishes, all blocks cleared once", s.finished && s.model.remainingTotal() == 0 && s.model.cleared == total);
        check("sim 3x3 ability: about 1/9 as many targets as blocks (<=1.25x ideal)", s.targets <= 1.25 * total / 9.0);
        check("sim 3x3 ability: first target is the centre cell", s.mined.get(0)[1] == 13 + 13 * 27);
        System.out.printf("      3x3: %d targets for %d blocks%n", s.targets, total);
    }

    static void abilityInactiveFallback() {
        // the controller falls back to single blocks when the ability does not trigger; the brain must cope with a
        // footprint change in the middle of a layer
        Sim s = new Sim(40, 20, 10, 10, 10, 9, 9, 2, false, square(3), LayerPlan.Order.CENTER_OUT);
        s.run(150, null);
        s.footprint = SINGLE;           // ability disabled: only the centre breaks from now on
        s.brain.invalidatePlan();
        s.run(10_000_000L, null);
        check("sim ability fallback: re-plans to single blocks and still finishes", s.finished && s.model.remainingTotal() == 0 && s.model.cleared == 162);
    }

    // ------------------------------------------------------------------ unit tests

    static void aimTests() {
        AimSmoother sm = new AimSmoother();
        double pos = 0, target = 90, maxV = 20, acc = 5, k = 0.35, maxStep = 0, maxAcc = 0, prevVel = 0;
        boolean overshoot = false, monotone = true;
        int ticksToSettle = -1;
        double last = pos;
        for (int t = 0; t < 200; t++) {
            double d = sm.step(target - pos, maxV, acc, k);
            pos += d;
            if (pos > target + 1e-9) overshoot = true;
            if (pos < last - 1e-9) monotone = false;
            last = pos;
            maxStep = Math.max(maxStep, Math.abs(d));
            maxAcc = Math.max(maxAcc, Math.abs(sm.velocity() - prevVel));
            prevVel = sm.velocity();
            if (Math.abs(target - pos) <= AimSmoother.DEADBAND && Math.abs(sm.velocity()) < 0.8 && ticksToSettle < 0) ticksToSettle = t;
        }
        check("aim: 90 deg turn never overshoots", !overshoot);
        check("aim: 90 deg turn is monotone (no oscillation)", monotone);
        check("aim: speed never exceeds the limit", maxStep <= maxV + 1e-9);
        check("aim: acceleration never exceeds the limit", maxAcc <= acc + 1e-9);
        check("aim: 90 deg turn settles within 14 ticks (0.7 s)", ticksToSettle >= 0 && ticksToSettle <= 14);

        sm = new AimSmoother(); pos = 0; overshoot = false; target = 3;
        for (int t = 0; t < 30; t++) { pos += sm.step(target - pos, maxV, acc, k); if (pos > target + 1e-9) overshoot = true; }
        check("aim: small 3 deg correction lands within the 0.25 deg deadband without overshoot", !overshoot && Math.abs(pos - target) <= AimSmoother.DEADBAND);

        // retarget mid-turn: 0 -> 80, then at tick 4 the target moves to 20
        sm = new AimSmoother(); pos = 0; target = 80; double minSeen = 1e9; boolean jerk = false; prevVel = 0;
        for (int t = 0; t < 80; t++) {
            if (t == 4) target = 20;
            pos += sm.step(target - pos, maxV, acc, k);
            if (Math.abs(sm.velocity() - prevVel) > acc + 1e-9) jerk = true;
            prevVel = sm.velocity();
        }
        check("aim: retargeting mid-turn is smooth (no velocity jump) and ends on the new target", !jerk && Math.abs(pos - 20) <= AimSmoother.DEADBAND);

        // tiny changes of a tracked target do not make it jitter
        sm = new AimSmoother(); pos = 0; target = 10;
        for (int t = 0; t < 40; t++) pos += sm.step(target - pos, maxV, acc, k);
        int signFlips = 0; double lastD = 0;
        for (int t = 0; t < 60; t++) {
            target = 10 + 0.02 * Math.sin(t);
            double d = sm.step(target - pos, maxV, acc, k);
            pos += d;
            if (d != 0 && lastD != 0 && Math.signum(d) != Math.signum(lastD)) signFlips++;
            if (d != 0) lastD = d;
        }
        check("aim: sub-degree wobble of the target causes no camera jitter (<=2 direction flips in 60 ticks)", signFlips <= 2);
    }

    static void steerTests() {
        List<int[]> straight = new ArrayList<>();
        for (int i = 0; i < 8; i++) straight.add(new int[]{i, 5, 0});
        check("steer: looks ahead along a straight run", PathSteer.carrotIndex(straight, 2, 2.4, 0.5, 1.5) > 2);
        List<int[]> corner = new ArrayList<>();
        for (int i = 0; i < 4; i++) corner.add(new int[]{i, 5, 0});
        for (int i = 1; i < 4; i++) corner.add(new int[]{3, 5, i});
        check("steer: never looks past a corner (index of the corner node)", PathSteer.carrotIndex(corner, 3, 2.8, 0.5, 3.0) == 3);
        List<int[]> step = new ArrayList<>();
        step.add(new int[]{0, 5, 0}); step.add(new int[]{1, 5, 0}); step.add(new int[]{2, 6, 0}); step.add(new int[]{3, 6, 0});
        check("steer: never looks across a step up", PathSteer.carrotIndex(step, 1, 1.4, 0.5, 3.0) == 1);
    }

    static void selectorTests() {
        QuarryModel m = new QuarryModel(new Quarry(new BlockPos(0, 0, 0), new BlockPos(8, 0, 8), "t"));
        for (int i = 0; i < 81; i++) m.layers[0].set(i, CellState.REMAINING);
        LayerPlan plan = new LayerPlan(m, 0, SINGLE, false, LayerPlan.Order.CENTER_OUT);
        while (!plan.step(1000)) { }
        check("plan: centre-out starts at the centre cell", plan.upcoming(1).get(0) == 4 + 4 * 9);
        List<Integer> seq = plan.upcoming(81);
        boolean ringsNonDecreasing = true;
        for (int i = 1; i < seq.size(); i++) if (plan.ringOf(seq.get(i)) < plan.ringOf(seq.get(i - 1))) ringsNonDecreasing = false;
        check("plan: centre-out visits rings in non-decreasing order and covers all 81 cells",
                ringsNonDecreasing && new HashSet<>(seq).size() == 81);

        TargetSelector sel = new TargetSelector(64, 4);
        Set<Integer> none = new HashSet<>();
        List<Integer> order = new ArrayList<>();
        for (int n = 0; n < 81; n++) {
            plan.pruneHead();
            TargetSelector.Choice c = sel.select(plan, 9, 0, 0, i -> 0, none, new ArrayList<>());
            if (c == null) break;
            order.add(c.idx);
            m.layers[0].set(c.idx, CellState.EMPTY);
            sel.noteDone(c.idx);
        }
        int far = 0;
        for (int i = 1; i < order.size(); i++)
            if (Math.hypot(order.get(i) % 9 - order.get(i - 1) % 9, order.get(i) / 9 - order.get(i - 1) / 9) > 3.0) far++;
        check("selector: clears all 81 cells", order.size() == 81);
        check("selector: starts at the centre", order.get(0) == 40);
        check("selector: hops between distant cells are rare (<=10%)", far <= 8);

        // unreachable candidates are reported, then the selector moves on
        m = new QuarryModel(new Quarry(new BlockPos(0, 0, 0), new BlockPos(8, 0, 8), "t"));
        for (int i = 0; i < 81; i++) m.layers[0].set(i, CellState.REMAINING);
        plan = new LayerPlan(m, 0, SINGLE, false, LayerPlan.Order.CENTER_OUT);
        while (!plan.step(1000)) { }
        List<Integer> failed = new ArrayList<>();
        TargetSelector.Choice c = new TargetSelector(64, 4).select(plan, 9, 0, 0, i -> i == 40 ? -1 : 1, none, failed);
        check("selector: unreachable centre is reported and another cell is chosen", failed.contains(40) && c != null && c.idx != 40);
    }

    static void brainTests() {
        QuarryModel m = new QuarryModel(new Quarry(new BlockPos(0, 0, 0), new BlockPos(4, 0, 4), "t"));
        for (int i = 0; i < 25; i++) m.layers[0].set(i, CellState.REMAINING);
        MiningBrain b = new MiningBrain(m, new MiningBrain.Params(64, 4, 3, false, LayerPlan.Order.CENTER_OUT));
        b.enterNextLayer();
        b.planStep(SINGLE, 1000);
        Set<Integer> unreachable = new HashSet<>(Arrays.asList(0, 1, 2));
        int mined = 0, steps = 0;
        while (steps++ < 10000) {
            MiningBrain.Pick p = b.pick(0, 0, i -> unreachable.contains(i) ? -1 : 1);
            if (p.kind == MiningBrain.Kind.TARGET) { m.observe(m.q.cellX(p.idx), 0, m.q.cellZ(p.idx), CellState.EMPTY); b.targetDone(p.idx); mined++; }
            else if (p.kind == MiningBrain.Kind.IDLE) break;
            else if (p.kind == MiningBrain.Kind.REPLAN) b.planStep(SINGLE, 1000);
        }
        check("brain: terminates with 3 unreachable blocks (22 mined, 3 skipped)", mined == 22 && m.skippedTotal() == 3 && m.remainingTotal() == 0);
    }

    public static void main(String[] a) {
        aimTests();
        steerTests();
        selectorTests();
        brainTests();
        smallQuarry();
        centreOutVsSerpentine();
        largeQuarry();
        unevenTerrain();
        obstaclesAndUnreachable();
        disappearingBlocks();
        pauseAndReload();
        longRunWithEvents();
        multiBlock();
        abilityInactiveFallback();
        System.out.println("\n" + passed + " passed, " + failed + " failed");
        System.exit(failed == 0 ? 0 : 1);
    }
}
