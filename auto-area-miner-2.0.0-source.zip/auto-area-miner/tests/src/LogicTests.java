import com.areaminer.area.*;
import com.areaminer.automation.*;
import com.areaminer.mining.MiningStats;
import com.areaminer.mining.TargetSelector;
import com.areaminer.pathfinding.LayerPlan;
import net.minecraft.util.math.BlockPos;

import java.util.*;

public class LogicTests {
    static int passed = 0, failed = 0;

    static void check(String name, boolean ok) {
        if (ok) { passed++; System.out.println("PASS  " + name); }
        else { failed++; System.out.println("FAIL  " + name); }
    }

    /** Grid world: blocks[x][y][z] true = solid. Default: solid floor at y=0, air above. */
    static class Grid implements Terrain {
        final Set<Long> solid = new HashSet<>();
        final Set<Long> hazard = new HashSet<>();
        void block(int x, int y, int z) { solid.add(Pathfinder.key(x, y, z)); }
        void floor(int x0, int x1, int z0, int z1, int y) { for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++) block(x, y, z); }
        public boolean passable(int x, int y, int z) { long k = Pathfinder.key(x, y, z); return !solid.contains(k) && !hazard.contains(k); }
        public boolean solidFloor(int x, int y, int z) { return solid.contains(Pathfinder.key(x, y, z)); }
    }

    static Pathfinder.Goal goalAt(int gx, int gy, int gz, int minY) {
        return new Pathfinder.Goal() {
            public boolean allowed(int x, int y, int z) { return y >= minY; }
            public boolean reached(int x, int y, int z) { return x == gx && y == gy && z == gz; }
            public double estimate(int x, int y, int z) { return Math.abs(x - gx) + Math.abs(z - gz) + Math.abs(y - gy); }
        };
    }

    static boolean validPath(Terrain t, List<int[]> p) {
        for (int i = 0; i < p.size(); i++) {
            int[] n = p.get(i);
            if (!Pathfinder.standable(t, n[0], n[1], n[2]) && i > 0) return false;
            if (i > 0) {
                int[] a = p.get(i - 1);
                int dx = Math.abs(n[0] - a[0]), dz = Math.abs(n[2] - a[2]), dy = n[1] - a[1];
                if (dx + dz != 1) return false;
                if (dy > 1 || dy < -3) return false;
            }
        }
        return true;
    }

    static void pathTests() {
        Grid g = new Grid();
        g.floor(0, 10, 0, 10, 0);
        List<int[]> p = Pathfinder.find(g, 0, 1, 0, goalAt(5, 1, 5, 0), 3000);
        check("path: flat ground found", p != null && p.size() == 11);
        check("path: flat ground is valid", p != null && validPath(g, p));

        // wall with a gap
        Grid w = new Grid();
        w.floor(0, 10, 0, 10, 0);
        for (int z = 0; z <= 10; z++) if (z != 8) { w.block(5, 1, z); w.block(5, 2, z); }
        p = Pathfinder.find(w, 0, 1, 0, goalAt(9, 1, 0, 0), 3000);
        boolean throughGap = false;
        if (p != null) for (int[] n : p) if (n[0] == 5 && n[2] == 8) throughGap = true;
        check("path: goes around a wall through the gap", p != null && throughGap && validPath(w, p));

        // fully walled -> unreachable
        Grid c = new Grid();
        c.floor(0, 10, 0, 10, 0);
        for (int z = 0; z <= 10; z++) { c.block(5, 1, z); c.block(5, 2, z); }
        p = Pathfinder.find(c, 0, 1, 0, goalAt(9, 1, 0, 0), 3000);
        check("path: sealed wall of height 2 -> no path", p == null);

        // wall of height 1 -> can jump
        Grid j = new Grid();
        j.floor(0, 10, 0, 10, 0);
        for (int z = 0; z <= 10; z++) j.block(5, 1, z);
        p = Pathfinder.find(j, 0, 1, 0, goalAt(9, 1, 0, 0), 3000);
        boolean jumped = false;
        if (p != null) for (int[] n : p) if (n[1] == 2) jumped = true;
        check("path: jumps over a 1-high wall", p != null && jumped && validPath(j, p));

        // drop of 2 is allowed, climbing 2 is not
        Grid d = new Grid();
        d.floor(0, 3, 0, 3, 2);
        d.floor(4, 8, 0, 3, 0);
        p = Pathfinder.find(d, 0, 3, 0, goalAt(6, 1, 0, 0), 3000);
        check("path: drops 2 blocks to lower ground", p != null && validPath(d, p));
        p = Pathfinder.find(d, 6, 1, 0, goalAt(0, 3, 0, 0), 3000);
        check("path: cannot climb 2 blocks back up", p == null);

        // hazard avoided
        Grid h = new Grid();
        h.floor(0, 4, 0, 2, 0);
        for (int z = 0; z <= 2; z++) if (z != 1) h.hazard.add(Pathfinder.key(2, 1, z));
        p = Pathfinder.find(h, 0, 1, 0, goalAt(4, 1, 0, 0), 3000);
        boolean touched = false;
        if (p != null) for (int[] n : p) if (h.hazard.contains(Pathfinder.key(n[0], n[1], n[2]))) touched = true;
        check("path: avoids hazard cells (detours via the safe row)", p != null && !touched);

        // minY constraint keeps the search out of pits
        Grid m = new Grid();
        m.floor(0, 6, 0, 0, 0);
        p = Pathfinder.find(m, 0, 1, 0, goalAt(6, 1, 0, 1), 3000);
        check("path: start cell as goal returns single node", Pathfinder.find(m, 0, 1, 0, goalAt(0, 1, 0, 0), 3000).size() == 1);

        // node cap
        Grid big = new Grid();
        big.floor(0, 200, 0, 200, 0);
        long t0 = System.nanoTime();
        p = Pathfinder.find(big, 0, 1, 0, goalAt(200, 1, 200, 0), 500);
        check("path: node cap stops the search (no hang)", p == null && (System.nanoTime() - t0) < 2_000_000_000L);
    }

    static void aimTests() {
        check("aim: south yaw 0", Math.abs(AimMath.yawTo(0, 1)) < 1e-4);
        check("aim: west yaw 90", Math.abs(AimMath.yawTo(-1, 0) - 90) < 1e-3);
        check("aim: east yaw -90", Math.abs(AimMath.yawTo(1, 0) + 90) < 1e-3);
        check("aim: north yaw 180", Math.abs(Math.abs(AimMath.yawTo(0, -1)) - 180) < 1e-3);
        check("aim: straight down pitch 90", Math.abs(AimMath.pitchTo(0, -1, 0) - 90) < 1e-3);
        check("aim: level pitch 0", Math.abs(AimMath.pitchTo(3, 0, 4)) < 1e-4);
        check("aim: wrap 350 -> -10", Math.abs(AimMath.wrap(350) + 10) < 1e-4);
        check("aim: wrap -190 -> 170", Math.abs(AimMath.wrap(-190) - 170) < 1e-4);
    }


    static void smoothTests() {
        // 90 degree turn: reaches the target, never overshoots, speed/accel limits respected
        AimSmoother sm = new AimSmoother();
        double pos = 0, target = 90, maxSpeed = 18, accel = 4, stiff = 0.22, prevVel = 0, maxVelSeen = 0, maxAccelSeen = 0;
        boolean overshoot = false, signFlip = false;
        int ticks = 0;
        double prevErr = target - pos;
        for (ticks = 1; ticks <= 200; ticks++) {
            double err = target - pos;
            double d = sm.step(err, maxSpeed, accel, stiff);
            pos += d;
            if (pos > target + 1e-9) overshoot = true;
            maxVelSeen = Math.max(maxVelSeen, Math.abs(sm.velocity()));
            maxAccelSeen = Math.max(maxAccelSeen, Math.abs(sm.velocity() - prevVel));
            prevVel = sm.velocity();
            if (Math.abs(target - pos) < 0.01) break;
        }
        check("camera: 90 degree turn arrives (" + ticks + " ticks)", Math.abs(target - pos) < 0.05 && ticks < 40);
        check("camera: never overshoots the target", !overshoot);
        check("camera: speed limit respected", maxVelSeen <= maxSpeed + 1e-6);
        check("camera: acceleration limit respected (max " + String.format("%.2f", maxAccelSeen) + ")", maxAccelSeen <= accel + 1e-6);

        // small corrections do not jitter: error 0.4 deg settles without sign flips
        sm = new AimSmoother(); pos = 0; target = 0.4; int flips = 0; double lastSign = 0;
        for (int i = 0; i < 60; i++) {
            double d = sm.step(target - pos, maxSpeed, accel, stiff);
            pos += d;
            double sg = Math.signum(d);
            if (sg != 0 && lastSign != 0 && sg != lastSign) flips++;
            if (sg != 0) lastSign = sg;
        }
        check("camera: tiny correction settles with no oscillation", flips == 0 && Math.abs(pos - target) < 0.06);

        // re-target mid-turn (moving target): velocity stays continuous, no snapping
        sm = new AimSmoother(); pos = 0; double tgt = 60; double maxJump = 0, last = 0; prevVel = 0; maxAccelSeen = 0;
        for (int i = 0; i < 80; i++) {
            if (i == 6) tgt = 20;     // target swings back while we are still accelerating
            if (i == 30) tgt = 75;
            double d = sm.step(tgt - pos, maxSpeed, accel, stiff);
            maxAccelSeen = Math.max(maxAccelSeen, Math.abs(sm.velocity() - prevVel));
            prevVel = sm.velocity();
            maxJump = Math.max(maxJump, Math.abs(d));
            pos += d;
        }
        check("camera: re-targeting keeps motion continuous (max accel " + String.format("%.2f", maxAccelSeen) + ")", maxAccelSeen <= accel + 1e-6 && maxJump <= maxSpeed + 1e-6);
        check("camera: ends on the final target", Math.abs(pos - 75) < 0.1);

        // a wrapped angle error (350 -> 10 is a 20 degree turn, not 340)
        check("camera: shortest way round the circle", Math.abs(AimMath.wrap(10 - 350) - 20) < 1e-4);
    }

    static void steerTests() {
        List<int[]> straight = new ArrayList<>();
        for (int i = 0; i < 8; i++) straight.add(new int[]{i, 1, 0});
        int c = PathSteer.carrot(straight, 1, 1.5, 0.5, 2.5);
        check("steer: looks ahead along a straight run (node " + c + ")", c > 1 && c <= 4);
        List<int[]> corner = new ArrayList<>();
        corner.add(new int[]{0, 1, 0}); corner.add(new int[]{1, 1, 0}); corner.add(new int[]{2, 1, 0}); corner.add(new int[]{2, 1, 1}); corner.add(new int[]{2, 1, 2});
        c = PathSteer.carrot(corner, 1, 1.5, 0.5, 5.0);
        check("steer: never looks past a corner (cuts no corners)", c == 2);
        List<int[]> step = new ArrayList<>();
        step.add(new int[]{0, 1, 0}); step.add(new int[]{1, 1, 0}); step.add(new int[]{2, 2, 0}); step.add(new int[]{3, 2, 0});
        c = PathSteer.carrot(step, 0, 0.5, 0.5, 5.0);
        check("steer: never looks across a step up", c == 1);
        check("steer: last node returns itself", PathSteer.carrot(straight, 7, 7.5, 0.5, 3) == 7);
    }

    static void centreOutTests() {
        int[][] fp1 = {{0, 0, 0}};
        QuarryModel m = allSolid(7, 1, 7);
        LayerPlan plan = new LayerPlan(m, 0, fp1, false, LayerPlan.Order.CENTER_OUT);
        while (!plan.step(10)) { }
        List<Integer> all = plan.upcoming(100);
        check("centre-out: plans every block exactly once", all.size() == 49 && new HashSet<>(all).size() == 49);
        check("centre-out: starts at the geometric centre", all.get(0) == 3 * 7 + 3);
        boolean mono = true;
        for (int i = 1; i < all.size(); i++) if (plan.ringOf(all.get(i)) < plan.ringOf(all.get(i - 1))) mono = false;
        check("centre-out: rings expand outward only", mono);
        boolean adjacent = true;
        for (int i = 2; i < all.size(); i++) {
            int a = all.get(i - 1), b = all.get(i);
            if (plan.ringOf(a) == plan.ringOf(b) && Math.max(Math.abs(a % 7 - b % 7), Math.abs(a / 7 - b / 7)) > 1) adjacent = false;
        }
        check("centre-out: neighbouring targets in a ring are adjacent (no hopping)", adjacent);

        m = allSolid(8, 1, 5); // even/odd sizes: centre still well defined, nothing missed
        plan = new LayerPlan(m, 0, fp1, false, LayerPlan.Order.CENTER_OUT);
        while (!plan.step(10)) { }
        check("centre-out: non-square 8x5 layer fully covered", new HashSet<>(plan.upcoming(100)).size() == 40);

        // selector: stays on the inner ring, then follows the previous target
        m = allSolid(9, 1, 9);
        plan = new LayerPlan(m, 0, fp1, false, LayerPlan.Order.CENTER_OUT);
        while (!plan.step(10)) { }
        TargetSelector sel = new TargetSelector(64, 4);
        Set<Integer> none = new HashSet<>();
        List<Integer> failed = new ArrayList<>();
        TargetSelector.Choice ch = sel.select(plan, 9, 0, 0, idx -> 0, none, failed);
        check("selector: first pick is the centre even when the player starts in a corner", ch != null && ch.idx == 4 * 9 + 4);
        m.layers[0].set(ch.idx, CellState.EMPTY);
        sel.noteDone(ch.idx);
        plan.pruneHead();
        int prev = ch.idx; boolean ringFirst = true; int visited = 1;
        while (true) {
            plan.pruneHead();
            ch = sel.select(plan, 9, 0, 0, idx -> 0, none, failed);
            if (ch == null) break;
            if (plan.ringOf(ch.idx) > 1 && visited < 9) ringFirst = false;
            m.layers[0].set(ch.idx, CellState.EMPTY);
            sel.noteDone(ch.idx);
            visited++;
        }
        check("selector: finishes ring 0 and ring 1 (9 blocks) before any outer block", ringFirst && visited == 81);

        // unreachable candidates are reported and skipped
        m = allSolid(5, 1, 5);
        plan = new LayerPlan(m, 0, fp1, false, LayerPlan.Order.CENTER_OUT);
        while (!plan.step(10)) { }
        sel = new TargetSelector(64, 4);
        failed = new ArrayList<>();
        final int centre = 2 * 5 + 2;
        ch = sel.select(plan, 5, 0, 0, idx -> idx == centre ? -1 : 0, none, failed);
        check("selector: unreachable centre is reported as failed", failed.contains(centre) && (ch == null || ch.idx != centre));
    }

    static QuarryModel allSolid(int sx, int sy, int sz) {
        Quarry q = new Quarry(new BlockPos(0, 0, 0), new BlockPos(sx - 1, sy - 1, sz - 1), "test");
        QuarryModel m = new QuarryModel(q);
        for (LayerData l : m.layers) for (int i = 0; i < l.size(); i++) l.set(i, CellState.REMAINING);
        return m;
    }

    static void planTests() {
        int[][] fp3 = new int[9][];
        int n = 0;
        for (int dz = -1; dz <= 1; dz++) for (int dx = -1; dx <= 1; dx++) fp3[n++] = new int[]{dx, 0, dz};
        int[][] fp1 = {{0, 0, 0}};

        QuarryModel m = allSolid(9, 1, 9);
        LayerPlan plan = new LayerPlan(m, 0, fp3, false);
        while (!plan.step(100)) { }
        check("plan: 9x9 layer with 3x3 pattern needs exactly 9 centres", plan.plannedCentres() == 9);
        check("plan: no leftovers on 9x9", plan.leftoverRemaining() == 0);

        // every centre's whole pattern is inside the quarry, and every cell covered
        boolean inside = true;
        boolean[][] cov = new boolean[9][9];
        for (int idx : plan.upcoming(100)) {
            int cx = idx % 9, cz = idx / 9;
            for (int[] o : fp3) {
                int x = cx + o[0], z = cz + o[2];
                if (x < 0 || z < 0 || x >= 9 || z >= 9) inside = false; else cov[z][x] = true;
            }
        }
        boolean all = true;
        for (boolean[] r : cov) for (boolean b : r) all &= b;
        check("plan: all patterns stay inside the quarry", inside);
        check("plan: every cell is covered", all);

        m = allSolid(10, 1, 10);
        plan = new LayerPlan(m, 0, fp3, false);
        while (!plan.step(100)) { }
        cov = new boolean[10][10];
        inside = true;
        for (int idx : plan.upcoming(1000)) {
            int cx = idx % 10, cz = idx / 10;
            for (int[] o : fp3) {
                int x = cx + o[0], z = cz + o[2];
                if (x < 0 || z < 0 || x >= 10 || z >= 10) inside = false; else cov[z][x] = true;
            }
        }
        all = true;
        for (boolean[] r : cov) for (boolean b : r) all &= b;
        check("plan: 10x10 (not a multiple of 3) stays inside and covers everything", inside && all && plan.leftoverRemaining() == 0);
        check("plan: 10x10 uses at most 16 centres", plan.plannedCentres() <= 16);

        m = allSolid(2, 1, 5);
        plan = new LayerPlan(m, 0, fp3, false);
        while (!plan.step(100)) { }
        check("plan: 2-wide strip cannot host a 3x3 -> all leftovers", plan.plannedCentres() == 0 && plan.leftoverRemaining() == 10);
        plan = new LayerPlan(m, 0, fp3, true);
        while (!plan.step(100)) { }
        check("plan: allowOvershoot lets the strip be planned", plan.plannedCentres() > 0 && plan.leftoverRemaining() == 0);

        m = allSolid(6, 1, 6);
        plan = new LayerPlan(m, 0, fp1, false);
        while (!plan.step(7)) { }
        check("plan: normal pickaxe = one centre per block", plan.plannedCentres() == 36);
        List<Integer> first = plan.upcoming(7);
        boolean serpentine = first.get(5) == 5 && first.get(6) == 11; // row 0 left->right, then row 1 starts at the right end
        check("plan: serpentine order (row 1 starts at the far end)", serpentine);

        // centre must be a real block: hole in the middle
        m = allSolid(3, 1, 3);
        m.layers[0].set(4, CellState.EMPTY);
        plan = new LayerPlan(m, 0, fp3, false);
        while (!plan.step(100)) { }
        check("plan: centre over air is rejected, edge cells still planned individually or via a solid centre",
                plan.leftoverRemaining() == 8 || plan.plannedCentres() >= 1);
    }

    static void modelTests() {
        QuarryModel m = allSolid(3, 1, 3);
        boolean first = m.observe(1, 0, 1, CellState.EMPTY);
        boolean again = m.observe(1, 0, 1, CellState.EMPTY);
        check("model: removal counted once", first && !again && m.cleared == 1);
        check("model: remaining decreases", m.remainingTotal() == 8);
        boolean reappear = m.observe(1, 0, 1, CellState.REMAINING);
        check("model: reappearing block is not 'cleared'", !reappear && m.remainingTotal() == 9 && m.cleared == 1);
        m.observe(0, 0, 0, CellState.SKIPPED);
        boolean sk = m.observe(0, 0, 0, CellState.REMAINING);
        check("model: skipped cell stays skipped until retried", !sk && m.layers[0].get(0) == CellState.SKIPPED);
        boolean skCleared = m.observe(0, 0, 0, CellState.EMPTY);
        check("model: skipped cell later seen as air counts once", skCleared && m.cleared == 2);
        check("model: percent sane", m.percent() > 0 && m.percent() < 100);

        MiningStats s = new MiningStats();
        for (int i = 0; i < 30; i++) s.record(i);
        check("stats: blocks/min window", Math.abs(s.blocksPerMinute(30) - 30) < 1e-9 && s.total() == 30);
        check("stats: old entries expire", s.blocksPerMinute(5000) == 0);
    }

    public static void main(String[] a) {
        pathTests();
        aimTests();
        planTests();
        modelTests();
        smoothTests();
        steerTests();
        centreOutTests();
        System.out.println("\n" + passed + " passed, " + failed + " failed");
        System.exit(failed == 0 ? 0 : 1);
    }
}
