import com.areaminer.area.*;
import com.areaminer.automation.*;
import com.areaminer.mining.MiningBrain;
import com.areaminer.mining.TargetSelector;
import com.areaminer.pathfinding.LayerPlan;
import net.minecraft.util.math.BlockPos;

import java.util.*;

/**
 * Headless simulation of the mining decision loop: the REAL MiningBrain, LayerPlan, TargetSelector,
 * Pathfinder and QuarryModel driven against a block-grid world with simple walking/mining physics.
 * It tests the planning and navigation logic, NOT Minecraft itself (no camera, input or networking).
 */
public class SimTests {
    static int passed = 0, failed = 0;

    static void check(String name, boolean ok) {
        if (ok) { passed++; System.out.println("PASS  " + name); }
        else { failed++; System.out.println("FAIL  " + name); }
    }

    static final double REACH = 4.15;

    static class World implements Terrain {
        final Set<Long> solid = new HashSet<>();
        void put(int x, int y, int z) { solid.add(Pathfinder.key(x, y, z)); }
        void remove(int x, int y, int z) { solid.remove(Pathfinder.key(x, y, z)); }
        boolean isSolid(int x, int y, int z) { return solid.contains(Pathfinder.key(x, y, z)); }
        public boolean passable(int x, int y, int z) { return !isSolid(x, y, z); }
        public boolean solidFloor(int x, int y, int z) { return isSolid(x, y, z); }
    }

    static class Metrics {
        long ticks, walkSteps, repaths, targets, farSwitches, deferred, vanished, gaveUp, singleToolSwaps, abilityFallbacks;
        long maxNoProgress;
        List<int[]> mined = new ArrayList<>(); // {layer, idx}
        boolean finished;
    }

    static class Sim {
        final World w;
        final Quarry q;
        QuarryModel model;
        MiningBrain brain;
        final Random rng;
        int px, py, pz;
        int[][] fp = {{0, 0, 0}};
        final int[][] multi;
        boolean abilityWorks;
        final Metrics m = new Metrics();
        int abilityMisses;
        long skippedPermanent;

        Sim(World w, Quarry q, int[][] multi, boolean abilityWorks, long seed) {
            this.w = w; this.q = q; this.multi = multi; this.abilityWorks = abilityWorks;
            this.rng = new Random(seed);
            if (multi != null) fp = multi;
        }

        void scanAll(long clearedOffset) {
            model = new QuarryModel(q);
            for (int l = 0; l < model.layers.length; l++) {
                LayerData d = model.layers[l];
                int y = q.yOfLayer(l);
                for (int i = 0; i < d.size(); i++) {
                    d.set(i, w.isSolid(q.cellX(i), y, q.cellZ(i)) ? CellState.REMAINING : CellState.EMPTY);
                }
            }
            model.cleared = clearedOffset;
            MiningBrain.Params p = new MiningBrain.Params();
            brain = new MiningBrain(model, p);
            brain.enterNextLayer();
        }

        boolean visible(int sx, int sy, int sz, int tx, int ty, int tz) {
            double ex = sx + 0.5, ey = sy + 1.62, ez = sz + 0.5;
            double[][] pts = {{0.5, 0.98, 0.5}, {0.5, 0.6, 0.02}, {0.5, 0.6, 0.98}, {0.02, 0.6, 0.5}, {0.98, 0.6, 0.5}};
            for (double[] o : pts) {
                double qx = tx + o[0], qy = ty + o[1], qz = tz + o[2];
                if (Math.sqrt((qx - ex) * (qx - ex) + (qy - ey) * (qy - ey) + (qz - ez) * (qz - ez)) > REACH) continue;
                boolean clear = true;
                int steps = 60;
                for (int s = 0; s < steps && clear; s++) {
                    double t = s / (double) steps;
                    int cx = (int) Math.floor(ex + (qx - ex) * t), cy = (int) Math.floor(ey + (qy - ey) * t), cz = (int) Math.floor(ez + (qz - ez) * t);
                    if ((cx != tx || cy != ty || cz != tz) && w.isSolid(cx, cy, cz)) clear = false;
                }
                if (clear) return true;
            }
            return false;
        }

        Pathfinder.Goal goalFor(int tx, int ty, int tz) {
            return new Pathfinder.Goal() {
                public boolean allowed(int x, int y, int z) { return y >= ty; }
                public boolean reached(int x, int y, int z) { return visible(x, y, z, tx, ty, tz); }
                public double estimate(int x, int y, int z) {
                    double dx = x + 0.5 - tx - 0.5, dy = y + 1.62 - ty - 0.5, dz = z + 0.5 - tz - 0.5;
                    return Math.max(0, Math.sqrt(dx * dx + dy * dy + dz * dz) - REACH);
                }
            };
        }

        void settle() { while (!w.isSolid(px, py - 1, pz) && py > -10) py--; }

        void breakCell(int x, int y, int z) {
            if (!w.isSolid(x, y, z)) return;
            w.remove(x, y, z);
            if (q.contains(x, y, z)) model.observe(x, y, z, CellState.EMPTY);
        }

        /** Runs until finished or maxTicks. @return the metrics. */
        Metrics run(long maxTicks, long pauseAt, long pauseLen, EventHook hook) {
            int state = 0; // 0 planning, 1 pick, 2 go, 3 mine
            int target = -1; int mineLeft = 0; int walkWait = 0;
            List<int[]> path = null; int pi = 0;
            long lastProgress = 0; long lastCleared = model.cleared;
            int lastTargetIdx = -1; int lastTargetLayer = -1;
            for (long t = 0; t < maxTicks; t++) {
                m.ticks = t;
                if (pauseAt >= 0 && t >= pauseAt && t < pauseAt + pauseLen) continue; // paused: nothing runs
                if (hook != null) hook.tick(this, t);
                if (model.cleared != lastCleared) { lastCleared = model.cleared; lastProgress = t; }
                m.maxNoProgress = Math.max(m.maxNoProgress, t - lastProgress);
                int layer = brain.layer();
                int ty = q.yOfLayer(layer);
                if (state == 0) {
                    if (brain.planStep(fp, 3000)) state = 1;
                    continue;
                }
                if (state == 1) {
                    final int pxr = px - q.minX, pzr = pz - q.minZ;
                    MiningBrain.Pick pick = brain.pick(pxr, pzr, idx -> {
                        int tx = q.cellX(idx), tz = q.cellZ(idx);
                        if (visible(px, py, pz, tx, ty, tz)) return 0;
                        List<int[]> p = Pathfinder.find(w, px, py, pz, goalFor(tx, ty, tz), 3000);
                        return p == null ? -1 : p.size();
                    });
                    switch (pick.kind) {
                        case TARGET -> {
                            target = pick.idx; m.targets++;
                            if (lastTargetIdx >= 0 && lastTargetLayer == layer) {
                                int dist = Math.max(Math.abs(q.cellX(target) - q.cellX(lastTargetIdx)), Math.abs(q.cellZ(target) - q.cellZ(lastTargetIdx)));
                                if (dist > 5) m.farSwitches++;
                            }
                            path = null; state = 2; walkWait = 0;
                        }
                        case RETRY -> { }
                        case NOTHING -> {
                            LayerData d = model.layers[layer];
                            if (d.remaining == 0 && d.unknown == 0) {
                                d.confirmedClear = true; // the sweeper's job in the real mod
                                if (!brain.enterNextLayer()) { m.finished = true; return m; }
                                state = 0; lastTargetIdx = -1;
                            }
                        }
                        case REPLAN -> state = 0;
                        case GAVE_UP -> { m.gaveUp += pick.count; }
                        case NEED_SINGLE_TOOL -> { m.singleToolSwaps++; fp = new int[][]{{0, 0, 0}}; brain.invalidatePlan(); state = 0; }
                    }
                    continue;
                }
                int tx = q.cellX(target), tz = q.cellZ(target);
                if (model.stateAt(tx, ty, tz) != CellState.REMAINING) { // vanished before we got there
                    m.vanished++; brain.targetDone(target); lastTargetIdx = target; lastTargetLayer = layer; state = 1; continue;
                }
                if (state == 3 || visible(px, py, pz, tx, ty, tz)) {
                    state = 3;
                    if (!visible(px, py, pz, tx, ty, tz)) { state = 2; path = null; continue; }
                    if (mineLeft <= 0) mineLeft = 3;
                    mineLeft--;
                    if (mineLeft > 0) continue;
                    int before = (int) model.cleared;
                    boolean wasMulti = fp.length > 1;
                    if (wasMulti && abilityWorks) {
                        for (int[] o : fp) breakCell(tx + o[0], ty + o[1], tz + o[2]);
                    } else {
                        breakCell(tx, ty, tz);
                    }
                    int got = (int) model.cleared - before;
                    mined(layer, target);
                    if (wasMulti) {
                        if (got <= 1) { abilityMisses++; } else abilityMisses = 0;
                        if (abilityMisses >= 2) { fp = new int[][]{{0, 0, 0}}; brain.invalidatePlan(); abilityMisses = 0; m.abilityFallbacks++; state = 0; lastTargetIdx = target; lastTargetLayer = layer; settle(); continue; }
                    }
                    settle();
                    brain.targetDone(target);
                    lastTargetIdx = target; lastTargetLayer = layer;
                    state = 1; continue;
                }
                // walk
                if (path == null) {
                    path = Pathfinder.find(w, px, py, pz, goalFor(tx, ty, tz), 3000);
                    if (path == null) { m.deferred++; brain.defer(target); state = 1; continue; }
                    pi = path.size() == 1 ? 0 : 1;
                }
                if (walkWait > 0) { walkWait--; continue; }
                int[] n = path.get(Math.min(pi, path.size() - 1));
                if (!Pathfinder.standable(w, n[0], n[1], n[2])) { m.repaths++; path = null; continue; }
                px = n[0]; py = n[1]; pz = n[2]; m.walkSteps++;
                walkWait = 3;
                pi++;
                if (pi >= path.size()) path = null;
            }
            return m;
        }

        void mined(int layer, int idx) { m.mined.add(new int[]{layer, idx}); }
    }

    interface EventHook { void tick(Sim s, long t); }

    static World ground(Quarry q, int margin) {
        World w = new World();
        for (int x = q.minX - margin; x <= q.maxX + margin; x++)
            for (int z = q.minZ - margin; z <= q.maxZ + margin; z++)
                for (int y = q.minY - 3; y <= q.maxY; y++) w.put(x, y, z);
        return w;
    }

    static Quarry quarry(int sx, int sy, int sz) {
        return new Quarry(new BlockPos(0, 0, 0), new BlockPos(sx - 1, sy - 1, sz - 1), "sim");
    }

    static boolean ringsNonDecreasing(Metrics m, Quarry q, int[][] fp1) {
        // within each layer the ring of consecutive mined cells never goes down (ignoring retried/deferred cells)
        int sx = q.sizeX(), sz = q.sizeZ(), cx = sx / 2, cz = sz / 2;
        int lastLayer = -1, lastRing = -1, violations = 0;
        for (int[] e : m.mined) {
            int idx = e[1];
            int ring = Math.max(Math.abs(idx % sx - cx), Math.abs(idx / sx - cz));
            if (e[0] == lastLayer && ring < lastRing) violations++;
            lastLayer = e[0]; lastRing = ring;
        }
        return violations == 0;
    }

    static boolean quarryEmpty(World w, Quarry q) {
        for (int x = q.minX; x <= q.maxX; x++) for (int y = q.minY; y <= q.maxY; y++) for (int z = q.minZ; z <= q.maxZ; z++)
            if (w.isSolid(x, y, z)) return false;
        return true;
    }

    static void startOutside(Sim s, Quarry q) {
        s.px = q.minX - 3; s.pz = q.minZ - 3; s.py = q.maxY + 1;
        s.settle();
    }

    public static void main(String[] a) {
        // 1. small 5x5x5
        {
            Quarry q = quarry(5, 5, 5);
            World w = ground(q, 6);
            Sim s = new Sim(w, q, null, false, 1);
            startOutside(s, q);
            s.scanAll(0);
            Metrics m = s.run(100000, -1, 0, null);
            check("5x5x5: finished", m.finished && quarryEmpty(w, q));
            int[] first = m.mined.get(0);
            check("5x5x5: first block mined is the centre of the top layer", first[0] == 0 && first[1] == 2 * 5 + 2);
            check("5x5x5: rings only expand outward within each layer", ringsNonDecreasing(m, q, null));
            check("5x5x5: no far target switching (" + m.farSwitches + ")", m.farSwitches == 0);
            check("5x5x5: all 125 blocks counted exactly once", s.model.cleared == 125 && m.mined.size() == 125);
            System.out.println("      ticks=" + m.ticks + " walkSteps=" + m.walkSteps + " targets=" + m.targets);
        }
        // 2. large quarry
        {
            Quarry q = quarry(41, 4, 41);
            World w = ground(q, 8);
            Sim s = new Sim(w, q, null, false, 2);
            startOutside(s, q);
            s.scanAll(0);
            Metrics m = s.run(2_000_000, -1, 0, null);
            check("41x4x41 large: finished", m.finished && quarryEmpty(w, q));
            check("41x4x41: centre first", m.mined.get(0)[1] == 20 * 41 + 20);
            check("41x4x41: rings non-decreasing", ringsNonDecreasing(m, q, null));
            check("41x4x41: far switches rare (" + m.farSwitches + " of " + m.targets + ")", m.farSwitches * 50 < m.targets);
            check("41x4x41: never stalled long (max " + m.maxNoProgress + " ticks)", m.maxNoProgress < 400);
            System.out.println("      ticks=" + m.ticks + " walkSteps=" + m.walkSteps + " targets=" + m.targets + " walk/target=" + String.format("%.2f", m.walkSteps / (double) m.targets));
        }
        // 3. uneven terrain: raised start area with steps, a ditch next to the quarry
        {
            Quarry q = quarry(9, 3, 9);
            World w = ground(q, 12);
            for (int x = q.minX - 12; x <= q.minX - 8; x++) for (int z = q.minZ - 12; z <= q.maxZ + 12; z++) { w.put(x, q.maxY + 1, z); }
            for (int x = q.minX - 12; x <= q.minX - 10; x++) for (int z = q.minZ - 12; z <= q.maxZ + 12; z++) { w.put(x, q.maxY + 2, z); }
            for (int x = q.minX - 3; x <= q.minX - 1; x++) for (int z = q.minZ - 12; z <= q.maxZ + 12; z++) { w.remove(x, q.maxY, z); }
            Sim s = new Sim(w, q, null, false, 3);
            s.px = q.minX - 12; s.pz = q.minZ + 4; s.py = q.maxY + 3; s.settle();
            s.scanAll(0);
            Metrics m = s.run(200000, -1, 0, null);
            check("uneven terrain (steps down, ditch): finished", m.finished && quarryEmpty(w, q));
            System.out.println("      ticks=" + m.ticks + " walkSteps=" + m.walkSteps);
        }
        // 4. obstacles: boulders and a wall around/over the top layer
        {
            Quarry q = quarry(11, 3, 11);
            World w = ground(q, 8);
            for (int[] b : new int[][]{{3, 3}, {3, 4}, {4, 3}, {7, 7}, {8, 7}, {7, 8}, {5, 5}})
                for (int y = q.maxY + 1; y <= q.maxY + 2; y++) w.put(b[0], y, b[1]);
            for (int z = -2; z <= 12; z++) if (z != 5) { w.put(-1, q.maxY + 1, z); w.put(-1, q.maxY + 2, z); }
            Sim s = new Sim(w, q, null, false, 4);
            startOutside(s, q);
            s.scanAll(0);
            Metrics m = s.run(400000, -1, 0, null);
            long solidLeft = 0;
            for (int x = q.minX; x <= q.maxX; x++) for (int y = q.minY; y <= q.maxY; y++) for (int z = q.minZ; z <= q.maxZ; z++) if (w.isSolid(x, y, z)) solidLeft++;
            check("obstacles: terminates (no infinite loop)", m.finished);
            check("obstacles: everything reachable was cleared (left " + solidLeft + ", skipped " + s.model.skippedTotal() + ")", solidLeft == s.model.skippedTotal());
            check("obstacles: nearly everything cleared", solidLeft <= 4);
            System.out.println("      ticks=" + m.ticks + " deferred=" + m.deferred + " repaths=" + m.repaths);
        }
        // 5. blocks vanishing and appearing unexpectedly
        {
            Quarry q = quarry(13, 4, 13);
            World w = ground(q, 8);
            Sim s = new Sim(w, q, null, false, 5);
            startOutside(s, q);
            s.scanAll(0);
            final long[] appeared = {0};
            EventHook hook = (sim, t) -> {
                if (t % 40 == 0) {
                    for (int k = 0; k < 3; k++) { // vanish
                        int l = sim.brain.layer();
                        int idx = sim.rng.nextInt(13 * 13);
                        int x = sim.q.cellX(idx), z = sim.q.cellZ(idx), y = sim.q.yOfLayer(l);
                        if (sim.w.isSolid(x, y, z)) { sim.w.remove(x, y, z); sim.model.observe(x, y, z, CellState.EMPTY); }
                    }
                }
                if (t % 97 == 0) { // gravel falls into a hole
                    int l = sim.brain.layer();
                    int idx = sim.rng.nextInt(13 * 13);
                    int x = sim.q.cellX(idx), z = sim.q.cellZ(idx), y = sim.q.yOfLayer(l);
                    boolean playerThere = (x == sim.px && z == sim.pz && (y == sim.py || y == sim.py + 1));
                    if (!sim.w.isSolid(x, y, z) && !playerThere && sim.w.isSolid(x, y - 1, z)) {
                        sim.w.put(x, y, z); sim.model.observe(x, y, z, CellState.REMAINING); appeared[0]++;
                    }
                }
            };
            long initial = 13 * 13 * 4;
            Metrics m = s.run(800000, -1, 0, hook);
            check("vanishing/appearing blocks: finished and quarry empty", m.finished && quarryEmpty(w, q));
            check("vanishing blocks: each block counted once (cleared " + s.model.cleared + " == " + (initial + appeared[0]) + ")",
                    s.model.cleared == initial + appeared[0]);
            System.out.println("      vanished-before-arrival=" + m.vanished + " appeared=" + appeared[0]);
        }
        // 6. pause and resume
        {
            Quarry q = quarry(7, 3, 7);
            World w = ground(q, 6);
            Sim s = new Sim(w, q, null, false, 6);
            startOutside(s, q);
            s.scanAll(0);
            Metrics m = s.run(200000, 120, 500, null);
            check("pause/resume: finishes with exact count after a 500-tick pause", m.finished && s.model.cleared == 7 * 7 * 3);
        }
        // 7. world reload mid-run: rescan, restore counter, continue
        {
            Quarry q = quarry(9, 3, 9);
            World w = ground(q, 6);
            Sim s = new Sim(w, q, null, false, 7);
            startOutside(s, q);
            s.scanAll(0);
            s.run(600, -1, 0, null); // part of the way
            long clearedBefore = s.model.cleared;
            check("reload: some progress before reload (" + clearedBefore + ")", clearedBefore > 0 && clearedBefore < 243);
            s.scanAll(clearedBefore);   // new session: fresh scan, saved counter restored
            s.px = q.minX - 3; s.pz = q.minZ - 3; s.py = q.maxY + 1; s.settle();
            Metrics m = new Metrics();
            Sim s2 = s;
            Metrics fin = s2.run(300000, -1, 0, null);
            check("reload: finishes and the counter ends at the true total (" + s.model.cleared + ")", fin.finished && s.model.cleared == 243 && quarryEmpty(w, q));
        }
        // 8. long run
        {
            Quarry q = quarry(61, 6, 61);
            World w = ground(q, 8);
            Sim s = new Sim(w, q, null, false, 8);
            startOutside(s, q);
            s.scanAll(0);
            long t0 = System.nanoTime();
            Metrics m = s.run(6_000_000, -1, 0, null);
            double sec = (System.nanoTime() - t0) / 1e9;
            check("61x6x61 long run (22,326 blocks): finished", m.finished && quarryEmpty(w, q));
            check("long run: no stall longer than 400 ticks (max " + m.maxNoProgress + ")", m.maxNoProgress < 400);
            check("long run: far target switches rare (" + m.farSwitches + " of " + m.targets + ")", m.farSwitches * 50 < m.targets);
            System.out.println("      simulated ticks=" + m.ticks + " (" + (m.ticks / 20 / 60) + " min of game time), wall time " + String.format("%.1f", sec) + " s");
        }
        // 9. multi-block 3x3 pattern, working and non-working ability
        int[][] fp3 = new int[9][];
        int n = 0;
        for (int dz = -1; dz <= 1; dz++) for (int dx = -1; dx <= 1; dx++) fp3[n++] = new int[]{dx, 0, dz};
        {
            Quarry q = quarry(21, 3, 21);
            World w = ground(q, 8);
            Sim s = new Sim(w, q, fp3, true, 9);
            startOutside(s, q);
            s.scanAll(0);
            Metrics m = s.run(600000, -1, 0, null);
            check("3x3 ability: finished", m.finished && quarryEmpty(w, q));
            check("3x3 ability: first centre is the middle of the layer", m.mined.get(0)[1] == 10 * 21 + 10);
            check("3x3 ability: about 1/9 as many targets as blocks (" + m.targets + " for " + (21 * 21 * 3) + ")", m.targets < 21 * 21 * 3 / 9 * 1.5);
            check("3x3 ability: every block counted once", s.model.cleared == 21 * 21 * 3);
            System.out.println("      targets=" + m.targets + " singleToolSwaps=" + m.singleToolSwaps);
        }
        {
            Quarry q = quarry(10, 2, 8);
            World w = ground(q, 8);
            Sim s = new Sim(w, q, fp3, true, 10);
            startOutside(s, q);
            s.scanAll(0);
            Metrics m = s.run(600000, -1, 0, null);
            check("3x3 on a 10x2x8 area (not multiples of 3): finished, nothing left", m.finished && quarryEmpty(w, q));
        }
        {
            Quarry q = quarry(12, 2, 12);
            World w = ground(q, 8);
            Sim s = new Sim(w, q, fp3, false, 11); // ability does NOT trigger
            startOutside(s, q);
            s.scanAll(0);
            Metrics m = s.run(600000, -1, 0, null);
            check("ability inactive: falls back to single blocks and still finishes (" + m.abilityFallbacks + " fallback)", m.finished && quarryEmpty(w, q) && m.abilityFallbacks >= 1);
        }
        {
            Quarry q = quarry(2, 2, 6);
            World w = ground(q, 8);
            Sim s = new Sim(w, q, fp3, true, 12);
            startOutside(s, q);
            s.scanAll(0);
            Metrics m = s.run(100000, -1, 0, null);
            check("3x3 on a 2-wide strip: asks for a 1-block tool, then finishes (" + m.singleToolSwaps + " swap)", m.finished && quarryEmpty(w, q) && m.singleToolSwaps >= 1);
        }
        System.out.println("\n" + passed + " passed, " + failed + " failed");
        System.exit(failed == 0 ? 0 : 1);
    }
}
