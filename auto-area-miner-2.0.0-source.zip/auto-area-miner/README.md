# Auto Area Miner 2.0.0 (Fabric, Minecraft 1.21.11)

Autonomous quarry miner for singleplayer and private local test worlds. Select two corners, press
Start: the player walks into the quarry, mines the middle first, and works outward ring by ring,
layer by layer, until the area is clear. On multiplayer it only gives manual-confirmation guidance.

## STATUS - read this first
**This source has NOT been compiled or run in Minecraft by the author** (no game or Minecraft downloads
were available). What was verified, honestly:
- 86 offline tests pass (`tests/run-logic-tests.sh`): 57 unit tests (pathfinding, camera smoothing, steering,
  centre-out planning, target selection, progress counting) and 29 checks from headless simulations of whole
  quarry runs (see "Testing" below).
- All files pass a javac syntax check; the only errors are Minecraft/Fabric classes missing from that machine.
- Version 1.1.0 (same code base, previous design) was built and run by you.
NOT verified (needs the real game): everything that touches Minecraft - key presses, camera feel, real
physics and collisions, block breaking, tool switching, item pickup, in-game timings.
Likeliest first-build compile errors: `ClientPlayConnectionEvents.JOIN` lambda, `PlayerInventory.getSelectedSlot`,
`Entity.getRotationVec`, `RaycastContext`, and `render/WorldOverlay.java` (your 1.1.0 build excluded it with
`-PnoWorldRender`; send me its compile error if you want the in-world outlines).

## Why 1.1.0 behaved badly (found by reading the code; not every item was observed in game)
1. **Tracker race (real bug).** The layer sweeper usually noticed a block disappearing before the target
   tracker did, so the tracker never saw "its" block go and waited out a 45 s timeout while the autopilot
   kept aiming at air / whatever was behind it. Now the shared model is the single source of truth.
2. **Order.** Plan was a row-by-row serpentine from a corner, and "first of the next 6 that is in reach" was
   chosen, so targets hopped around. Now centre-first, rings outward, nearest-neighbour inside the ring.
3. **Camera.** Steering aimed at each waypoint's exact centre (the heading flips violently when you are on
   top of it); the aim point was "first valid of 5", which flips as you move; easing had a 1.5 degree floor
   and pitch was forced to 12 degrees while walking. Now: look-ahead along straight stretches without
   cutting corners, heading held on waypoints, one locked aim point per target, and a speed/acceleration
   limited controller that brakes early and never overshoots.
4. **Standing still.** Up to ~20 s per target of re-aiming at an unreachable block. Now bounded (about 5 s),
   then another stand position is tried, then the block is set aside.
5. **Unreachable = lost forever.** Now set aside, retried once at the end of its layer, then skipped.
6. **Progress after a reload** restarted at 0%. Now the counter is restored (`config/areaminer/lastrun.json`).

## What changed in 2.0.0
- Centre-out mining (`miningOrder`: CENTER_OUT default, SERPENTINE kept; `/miner order center|serpentine`).
  Multi-block patterns are tiled on a lattice anchored at the middle of the layer (a 21x21 layer needs
  exactly 49 3x3 centres).
- `MiningBrain` + `TargetSelector` (pure, tested): ring-first, closest-to-previous-target, reachability
  probing of the best few candidates, deferral + one final retry per layer, bounded re-plans.
- Smooth camera: `aimMaxSpeed`, `aimAcceleration`, `aimStiffness`, `walkTurnSpeed` in the config
  (defaults: a 90 degree turn takes about 0.9 s).
- Navigation: look-ahead steering, next-3-cells validation, stuck recovery (hop, ban the cell + re-plan,
  give up), per-target time budget, stall watchdog (reset once, then pause with details).
- Quarry changes while running restart on the new area; world join restores your last quarry.
- HUD: layer + ring, mined/left/percent, blocks per minute, ETA, set-aside/skipped counts, held tool with uses
  left, navigation status, clear pause reason.
- Kept: all commands, GUI, profiles and calibration, safety pauses, DonutSMP refusal, singleplayer gating.

## Where autonomy is allowed (unchanged)
Singleplayer, or a private server only if you set `allowPrivateServers` (default false). Any address
containing "donut" is refused outright. Otherwise manual-confirmation mode. No packets are sent by the mod,
no reach extension, no teleporting, no anti-cheat bypass.

## Build (Windows)
1. JDK 21. 2. Copy `gradlew`, `gradlew.bat` and `gradle\` from another Fabric project into this folder.
3. Run `build.bat`. 4. Use `build\libs\auto-area-miner-2.0.0.jar` (not `-sources`) with Fabric API for 1.21.11.
If WorldOverlay fails: `gradlew build -PnoWorldRender`.

## Testing
Offline (any JDK 21): `sh tests/run-logic-tests.sh` or `tests\run-logic-tests.bat`.
The simulations drive the REAL MiningBrain/LayerPlan/TargetSelector/Pathfinder/QuarryModel against a block grid
with simple walking and mining. They test the decisions, not Minecraft's physics or input.
Covered: 5x5x5; 41x4x41; 61x6x61 (22k blocks, about 97 game-minutes simulated); uneven terrain with steps and
a ditch; boulders and a wall; blocks vanishing and gravel appearing mid-run; pause/resume; reload with counter
restore; 3x3 pattern (working, inactive, 2-wide strip, sizes not divisible by 3).
In-game suggested order: 5x5x5 creative stone cube; watch it go to the middle first; then 21x21x3; then
uneven ground; then place/break blocks during a run; /miner pause and /miner resume; leave and re-join the world.

## Commands
`/miner pos1 | pos2 | start | pause | resume | stop | status | clear | save <n> | load <n> | list |
profile [id|auto] | calibrate [save <id>] | retry | rescan | gui | overlay | mode [auto|manual] |
order [center|serpentine] | reload`

## Known limitations
- Needs somewhere to stand above the top layer (open air or a ramp); it only climbs 1 block.
- Half slabs, stairs, carpet and similar are not treated as floor, so routes avoid them.
- The camera is moved once per game tick (the game interpolates between ticks); feel needs in-game tuning.
- Vanilla has no 3x3 pickaxe; the ability only exists if a mod/datapack provides it.
- Path searches run on the client thread, bounded (`pathNodeLimit`), typically well under a millisecond.
