package com.areaminer.core;

import com.areaminer.area.CellState;
import com.areaminer.area.LayerData;
import com.areaminer.area.Quarry;
import com.areaminer.area.QuarryModel;
import com.areaminer.automation.AutoPilot;
import com.areaminer.automation.AutomationGate;
import com.areaminer.automation.ToolSelector;
import com.areaminer.config.MinerConfig;
import com.areaminer.config.RunStore;
import com.areaminer.inventory.InventoryMonitor;
import com.areaminer.mining.MiningBrain;
import com.areaminer.mining.MiningStats;
import com.areaminer.mining.MiningTracker;
import com.areaminer.mining.TargetSelector;
import com.areaminer.movement.ReachGuide;
import com.areaminer.pathfinding.LayerPlan;
import com.areaminer.pickaxe.Calibrator;
import com.areaminer.pickaxe.PickaxeProfile;
import com.areaminer.pickaxe.PickaxeProfiles;
import com.areaminer.recovery.StuckDetector;
import com.areaminer.scanner.CellClassifier;
import com.areaminer.scanner.CellSweeper;
import com.areaminer.scanner.QuarryScanner;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Owns the state machine and all Minecraft I/O. WHAT to mine next is decided by MiningBrain (pure,
 * headless-tested); HOW (walk, turn, hold attack) by AutoPilot; whether it worked by MiningTracker and
 * the shared QuarryModel. Everything runs on the client thread in small per-tick slices.
 */
public final class QuarryController {
    public enum Level { INFO, WARN, ERROR }

    public record Note(String text, Level level, long expireTick) { }

    private BlockPos pos1;
    private BlockPos pos2;
    private Quarry quarry;

    private MinerState state = MinerState.IDLE;
    private String pauseReason = "";
    private boolean autoPause;
    private boolean waitingForSingle;
    private String singleReason = "";

    private QuarryModel model;
    private QuarryScanner scanner;
    private CellClassifier classifier;
    private CellSweeper sweeper;
    private MiningBrain brain;
    private MiningTracker tracker;
    private final MiningStats stats = new MiningStats();
    private final StuckDetector stuck = new StuckDetector();
    private final Calibrator calibrator = new Calibrator();

    // autonomous mode
    private final AutoPilot autopilot = new AutoPilot();
    private boolean autoMode;
    private String modeNote = "";
    private boolean abilityDisabled;
    private String lastProfileId = "";
    private int[][] planFp;
    private PickaxeProfile planProfile;
    private int unreachableStreak;

    private BlockPos target;
    private int targetIdx = -1;
    private long targetAssignedTick;
    private String hint = "";
    private PickaxeProfile profile;
    private String profileOverride = "auto";
    private long tick;
    private long recoverUntil;
    private int chunkWait;
    private String errorMessage = "";
    private long lastClearedSeen;
    private long lastProgressTick;
    private int stallStage;
    private long lastSaveTick;
    private final ArrayDeque<Note> notes = new ArrayDeque<>();

    // ------------------------------------------------------------------ selection

    /** Changing the selection while running restarts on the new area instead of mining with a stale plan. */
    public void setPos(int which, BlockPos p) {
        boolean wasActive = isActive();
        if (wasActive) {
            stop();
        }
        if (which == 1) {
            pos1 = p.toImmutable();
        } else {
            pos2 = p.toImmutable();
        }
        quarry = null;
        if (pos1 != null && pos2 != null) {
            quarry = new Quarry(pos1, pos2, currentDimension());
            RunStore.save(quarry, RunStore.clearedFor(quarry));
        }
        restartIfNeeded(wasActive);
    }

    public void loadQuarry(Quarry q) {
        boolean wasActive = isActive();
        if (wasActive) {
            stop();
        }
        quarry = q;
        pos1 = new BlockPos(q.minX, q.minY, q.minZ);
        pos2 = new BlockPos(q.maxX, q.maxY, q.maxZ);
        RunStore.save(quarry, RunStore.clearedFor(quarry));
        restartIfNeeded(wasActive);
    }

    private void restartIfNeeded(boolean wasActive) {
        if (!wasActive || quarry == null) {
            return;
        }
        String err = start(MinecraftClient.getInstance());
        notify(err == null ? Level.INFO : Level.WARN,
                err == null ? "Selection changed - restarted on the new area." : "Selection changed, but it could not restart: " + err, true);
    }

    public void clearSelection() {
        stop();
        pos1 = null;
        pos2 = null;
        quarry = null;
        RunStore.delete();
    }

    private static String currentDimension() {
        ClientWorld w = MinecraftClient.getInstance().world;
        return w == null ? "unknown" : w.getRegistryKey().getValue().toString();
    }

    /** After joining a world: bring back the last quarry so it can simply be continued. */
    public void onJoin(MinecraftClient mc) {
        if (isActive() || quarry != null) {
            return;
        }
        Quarry last = RunStore.loadQuarry();
        if (last == null) {
            return;
        }
        quarry = last;
        pos1 = new BlockPos(last.minX, last.minY, last.minZ);
        pos2 = new BlockPos(last.maxX, last.maxY, last.maxZ);
        long done = RunStore.clearedFor(last);
        notify(Level.INFO, "Restored your last quarry (" + last.describe() + ")"
                + (done > 0 ? ", " + String.format("%,d", done) + " blocks already cleared" : "")
                + ". /miner start continues it.", true);
    }

    // ------------------------------------------------------------------ lifecycle

    public boolean isActive() {
        return state != MinerState.IDLE && state != MinerState.COMPLETED && state != MinerState.ERROR;
    }

    /** @return an error message, or null when started. */
    public String start(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) {
            return "Not in a world.";
        }
        if (quarry == null) {
            return "Set both corners first (/miner pos1 and /miner pos2).";
        }
        if (isActive()) {
            return "Already running (" + state + ").";
        }
        MinerConfig cfg = MinerConfig.get();
        if (quarry.volume() > cfg.maxVolume) {
            return "Selection has " + String.format("%,d", quarry.volume()) + " blocks; the limit is "
                    + String.format("%,d", cfg.maxVolume) + " (maxVolume in config/areaminer.json).";
        }
        if (!quarry.dimension.equals(currentDimension())) {
            return "This quarry was selected in " + quarry.dimension + ".";
        }
        resetRuntime();
        model = new QuarryModel(quarry);
        long previous = RunStore.clearedFor(quarry);
        model.cleared = previous;
        classifier = new CellClassifier(cfg);
        scanner = new QuarryScanner(model, classifier);
        sweeper = new CellSweeper(model, classifier);
        tracker = new MiningTracker(model, classifier, stats);
        brain = new MiningBrain(model, brainParams(cfg));
        String gate = AutomationGate.check(mc);
        autoMode = gate == null;
        modeNote = autoMode ? "autonomous" : gate;
        lastClearedSeen = model.cleared;
        lastProgressTick = tick;
        lastSaveTick = tick;
        stallStage = 0;
        state = MinerState.SCANNING;
        notify(Level.INFO, "Scanning " + quarry.describe() + "...", false);
        if (previous > 0) {
            notify(Level.INFO, "Continuing: " + String.format("%,d", previous) + " blocks were already cleared earlier.", false);
        }
        if (autoMode) {
            notify(Level.INFO, "Autonomous mode: the player will walk, aim and mine by itself ("
                    + ("SERPENTINE".equals(cfg.miningOrder) ? "row by row" : "centre first, then outward") + ").", false);
        } else {
            notify(Level.INFO, "Manual-confirmation mode: " + gate + ".", false);
        }
        return null;
    }

    private static MiningBrain.Params brainParams(MinerConfig cfg) {
        MiningBrain.Params pr = new MiningBrain.Params();
        pr.window = cfg.candidateWindow;
        pr.probes = cfg.probeCandidates;
        pr.maxReplans = cfg.maxReplans;
        pr.allowOvershoot = cfg.allowOvershoot;
        pr.order = "SERPENTINE".equals(cfg.miningOrder) ? LayerPlan.Order.SERPENTINE : LayerPlan.Order.CENTER_OUT;
        return pr;
    }

    public void pause(String reason, boolean auto) {
        if (!isActive() || state == MinerState.PAUSED || state == MinerState.SCANNING) {
            return;
        }
        dropTarget(MinecraftClient.getInstance());
        releaseInputs();
        saveProgress();
        state = MinerState.PAUSED;
        pauseReason = reason;
        autoPause = auto;
        notify(Level.WARN, "Paused: " + reason, true);
    }

    public void resume() {
        if (state != MinerState.PAUSED) {
            return;
        }
        releaseInputs();
        state = (brain == null || !brain.hasPlan()) ? MinerState.PLANNING : MinerState.MOVING;
        pauseReason = "";
        autoPause = false;
        target = null;
        lastProgressTick = tick;
        notify(Level.INFO, "Resumed.", false);
    }

    public void stop() {
        saveProgress();
        resetRuntime();
        state = MinerState.IDLE;
    }

    public void onDisconnect() {
        if (isActive()) {
            saveProgress();
            resetRuntime();
            state = MinerState.IDLE;
        }
        calibrator.cancel();
        notes.clear();
    }

    public void failFromException(Throwable t) {
        saveProgress();
        resetRuntime();
        state = MinerState.ERROR;
        errorMessage = t.getClass().getSimpleName() + ": " + t.getMessage();
        notify(Level.ERROR, "Internal error, stopped safely: " + errorMessage, true);
    }

    private void fail(String msg) {
        saveProgress();
        resetRuntime();
        state = MinerState.ERROR;
        errorMessage = msg;
        notify(Level.ERROR, msg, true);
    }

    private void saveProgress() {
        if (quarry != null && model != null) {
            RunStore.save(quarry, model.cleared);
        }
    }

    private void complete() {
        releaseInputs();
        long left = model.remainingTotal();
        long blocked = model.blockedTotal();
        long skipped = model.skippedTotal();
        long cleared = model.cleared;
        target = null;
        state = MinerState.COMPLETED;
        RunStore.save(quarry, 0L);
        String extra = "";
        if (blocked > 0) {
            extra += ", " + blocked + " need a better tool";
        }
        if (skipped > 0) {
            extra += ", " + skipped + " skipped (/miner retry)";
        }
        if (left > 0) {
            extra += ", " + left + " left";
        }
        notify(Level.INFO, "Quarry finished: " + String.format("%,d", cleared) + " blocks cleared" + extra + ".", true);
    }

    private void releaseInputs() {
        autopilot.reset(MinecraftClient.getInstance());
    }

    private void resetRuntime() {
        releaseInputs();
        abilityDisabled = false;
        planFp = null;
        planProfile = null;
        unreachableStreak = 0;
        autoMode = false;
        modeNote = "";
        lastProfileId = "";
        model = null;
        scanner = null;
        sweeper = null;
        classifier = null;
        brain = null;
        tracker = null;
        target = null;
        targetIdx = -1;
        chunkWait = 0;
        waitingForSingle = false;
        pauseReason = "";
        autoPause = false;
        hint = "";
        errorMessage = "";
        stallStage = 0;
        stats.reset();
    }

    /** @return number of skipped cells that were restored. */
    public int retrySkipped() {
        if (model == null || state == MinerState.SCANNING) {
            return 0;
        }
        int n = 0;
        for (LayerData d : model.layers) {
            for (int i = 0; i < d.size(); i++) {
                if (d.get(i) == CellState.SKIPPED) {
                    d.set(i, CellState.REMAINING);
                    n++;
                }
            }
        }
        if (n > 0) {
            dropTarget(MinecraftClient.getInstance());
            brain = new MiningBrain(model, brainParams(MinerConfig.get()));
            planFp = null;
            boolean any = brain.enterNextLayer();
            if (any) {
                sweeper.setLayer(brain.layer());
            }
            if (state == MinerState.COMPLETED || state == MinerState.ERROR) {
                if (any) {
                    state = MinerState.PLANNING;
                    lastProgressTick = tick;
                } else {
                    complete();
                }
            } else if (state != MinerState.PAUSED && any) {
                state = MinerState.PLANNING;
            }
        }
        return n;
    }

    // ------------------------------------------------------------------ per-tick

    public void tick(MinecraftClient mc) {
        tick++;
        ClientWorld w = mc.world;
        ClientPlayerEntity p = mc.player;
        if (w == null || p == null) {
            return;
        }
        calibrator.tick(mc);
        while (!notes.isEmpty() && notes.peekFirst().expireTick() < tick) {
            notes.pollFirst();
        }
        if (!isActive()) {
            return;
        }
        MinerConfig cfg = MinerConfig.get();
        if (!w.getRegistryKey().getValue().toString().equals(quarry.dimension)) {
            fail("Dimension changed - stopped.");
            return;
        }

        ItemStack held = p.getMainHandStack();
        profile = PickaxeProfiles.resolve(held, profileOverride);
        ItemStack tool = PickaxeProfiles.isMiningTool(held) ? held : null;

        String pid = profile == null ? "" : profile.id;
        if (!pid.equals(lastProfileId)) {
            lastProfileId = pid;
            abilityDisabled = false; // a different tool may have a working ability
        }
        if (autoMode) {
            String gate = AutomationGate.check(mc);
            if (gate != null) {
                autoMode = false;
                modeNote = gate;
                releaseInputs();
                notify(Level.WARN, "Autonomous mode switched off: " + gate + ". Continuing in manual-confirmation mode.", true);
            } else if (mc.currentScreen != null && state != MinerState.SCANNING && state != MinerState.PAUSED) {
                autopilot.releaseAll(mc); // never keep keys held behind a menu
                if (tracker != null) {
                    tracker.hold();
                }
                lastProgressTick = tick;
                return;
            }
        }

        if (state == MinerState.PAUSED) {
            if (!autoPause) {
                return;
            }
            String why = conditionProblem(p, held, true, cfg);
            if (why != null) {
                pauseReason = why;
                return;
            }
            resume();
            return;
        }
        String why = conditionProblem(p, held, false, cfg);
        if (why != null) {
            pause(why, true);
            return;
        }

        switch (state) {
            case SCANNING -> {
                if (scanner.step(w, tool, cfg.scanBudgetPerTick)) {
                    if (!nextLayer()) {
                        complete();
                    }
                }
            }
            case PLANNING -> planStep(cfg);
            default -> activeStep(mc, w, p, tool, cfg);
        }
    }

    /** Returns a reason to pause, or null when everything is fine. */
    private String conditionProblem(ClientPlayerEntity p, ItemStack held, boolean resuming, MinerConfig cfg) {
        if (!p.isAlive()) {
            return "You died - it resumes after you respawn.";
        }
        if (autoMode) {
            if (p.getHealth() < cfg.minHealth) {
                return "Health is low (" + Math.round(p.getHealth()) + "). It resumes when you have healed.";
            }
            if (p.isInLava() || p.isOnFire()) {
                return "You are in lava or on fire - stopped for safety.";
            }
        }
        int free = InventoryMonitor.freeSlots(p);
        int need = resuming ? cfg.minFreeSlots + 2 : cfg.minFreeSlots;
        if (cfg.pauseOnInventoryFull && free < need) {
            return "Inventory full (" + free + " free slot(s)). Empty some space.";
        }
        if (cfg.pauseOnLowDurability && PickaxeProfiles.isMiningTool(held)) {
            int left = InventoryMonitor.usesLeft(held);
            if (left <= cfg.lowDurabilityUses
                    && !(autoMode && cfg.autoSelectTool && ToolSelector.swapAwayFromLowDurability(p, cfg))) {
                return "Pickaxe durability low (" + left + " uses left). Swap or repair it.";
            }
        }
        if (waitingForSingle) {
            if (profile != null && !profile.isMultiBlock()) {
                waitingForSingle = false;
                brain.invalidatePlan();
                planFp = null;
                target = null;
            } else {
                return singleReason;
            }
        }
        return null;
    }

    private boolean nextLayer() {
        target = null;
        targetIdx = -1;
        planFp = null;
        if (tracker != null) {
            tracker.cancel();
        }
        if (brain.enterNextLayer()) {
            sweeper.setLayer(brain.layer());
            state = MinerState.PLANNING;
            return true;
        }
        return false;
    }

    private int[][] effectiveFootprint(PickaxeProfile pr) {
        return abilityDisabled ? new int[][]{{0, 0, 0}} : pr.footprint();
    }

    private void planStep(MinerConfig cfg) {
        planProfile = profile != null ? profile : (planProfile != null ? planProfile : PickaxeProfiles.normal());
        int[][] fp = planFp != null ? planFp : effectiveFootprint(planProfile);
        if (brain.planStep(fp, cfg.planBudgetPerTick)) {
            planFp = brain.planFp();
            state = MinerState.MOVING;
            target = null;
        }
    }

    private void dropTarget(MinecraftClient mc) {
        if (tracker != null) {
            tracker.cancel();
        }
        if (autoMode || autopilot.collecting()) {
            autopilot.onTargetDone(mc);
        }
        target = null;
        targetIdx = -1;
    }

    private void activeStep(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, ItemStack tool, MinerConfig cfg) {
        if (profile != null && planFp != null && !Arrays.deepEquals(effectiveFootprint(profile), planFp)) {
            dropTarget(mc);
            brain.invalidatePlan();
            planProfile = profile;
            planFp = null;
            state = MinerState.PLANNING;
            notify(Level.INFO, "Pickaxe is now " + profile.label() + " - replanning this layer.", false);
            return;
        }

        int layer = brain.layer();
        sweeper.setLayer(layer);
        sweeper.step(w, tool, cfg.sweepBudget, tick, stats);
        if (tick - lastSaveTick > 600) {
            saveProgress();
            lastSaveTick = tick;
        }

        if (autoMode && autopilot.collecting() && !tracker.active()) {
            AutoPilot.Result r = autopilot.collectTick(mc, w, p, model.q, model.q.yOfLayer(layer), cfg);
            if (r == AutoPilot.Result.COLLECTING) {
                state = MinerState.COLLECTING;
                hint = "Picking up dropped items...";
                return;
            }
        }

        if (!tracker.active() && brain.layerClear()) {
            notify(Level.INFO, "Layer " + (layer + 1) + "/" + model.layers.length + " complete.", true);
            if (!nextLayer()) {
                complete();
            }
            return;
        }

        if (autoMode && stalled(mc, cfg)) {
            return;
        }

        if (target != null) {
            MiningTracker.Event ev = tracker.tick(w, tick, tool, cfg);
            switch (ev) {
                case SETTLING -> {
                    if (autoMode) {
                        autopilot.stopMining(mc);
                    }
                    state = MinerState.VERIFYING;
                    hint = "Block broke - confirming with the server...";
                    return;
                }
                case FINISHED -> onTargetFinished(mc, cfg);
                case TIMED_OUT -> {
                    if (autoMode) {
                        autopilot.stopMining(mc);
                    }
                    state = MinerState.RECOVERING;
                    recoverUntil = tick + 40;
                    notify(Level.WARN, "Block not breaking (attempt " + tracker.attempts() + "/" + cfg.maxRetries
                            + "). Retrying with a fresh aim.", false);
                }
                case SKIPPED -> {
                    if (autoMode) {
                        autopilot.onTargetDone(mc);
                    }
                    notify(Level.WARN, "Skipped a block that would not break. /miner retry restores skipped blocks.", false);
                    target = null;
                    targetIdx = -1;
                }
                case NONE -> { }
            }
            if (state == MinerState.PLANNING) {
                return; // the ability fallback asked for a fresh plan
            }
        }

        if (target == null) {
            pickTarget(mc, w, p, cfg);
            if (target == null) {
                return;
            }
        }
        if (autoMode && tick - targetAssignedTick > cfg.targetBudgetSeconds * 20L) {
            deferTarget(mc, "it took longer than " + cfg.targetBudgetSeconds + " s");
            return;
        }
        if (state == MinerState.RECOVERING && tick < recoverUntil) {
            return;
        }
        guidance(mc, w, p, cfg);
    }

    /** No cleared block for stallSeconds: reset the target/navigation once, then pause with details. */
    private boolean stalled(MinecraftClient mc, MinerConfig cfg) {
        if (model.cleared != lastClearedSeen) {
            lastClearedSeen = model.cleared;
            lastProgressTick = tick;
            stallStage = 0;
            return false;
        }
        if (tick - lastProgressTick <= cfg.stallSeconds * 20L) {
            return false;
        }
        lastProgressTick = tick;
        stallStage++;
        if (stallStage == 1) {
            dropTarget(mc);
            brain.clearDeferred();
            brain.invalidatePlan();
            planFp = null;
            state = MinerState.PLANNING;
            notify(Level.WARN, "No progress for " + cfg.stallSeconds + " s - resetting target and navigation, then re-planning this layer.", true);
            return true;
        }
        stallStage = 0;
        pause("No progress even after a reset (last status: " + (hint.isEmpty() ? "none" : hint)
                + "). Check the area, your tool and the space around you, then /miner resume.", false);
        return true;
    }

    private void onTargetFinished(MinecraftClient mc, MinerConfig cfg) {
        int idx = targetIdx;
        target = null;
        targetIdx = -1;
        unreachableStreak = 0;
        if (idx >= 0) {
            brain.targetDone(idx);
        }
        if (autoMode) {
            autopilot.onTargetDone(mc);
            autopilot.beginCollect(cfg);
        }
        int expected = tracker.lastExpected();
        int broken = tracker.lastBroken();
        if (tracker.lastWasEvaluated() && expected > 1) {
            if (tracker.abilityMisses() >= 2) {
                if (autoMode && !abilityDisabled) {
                    abilityDisabled = true;
                    brain.invalidatePlan();
                    planFp = null;
                    state = MinerState.PLANNING;
                    notify(Level.WARN, "The multi-block ability did not trigger twice in a row, so this pattern is not "
                            + "active here. Mining single blocks instead. (Switching tools re-enables it.)", true);
                } else if (!autoMode) {
                    notify(Level.WARN, "The special ability doesn't seem to trigger (cooldown, not activated, or wrong profile). "
                            + "Only single blocks are breaking. Try /miner calibrate.", false);
                }
            } else if (broken > 1 && broken < expected) {
                notify(Level.INFO, "Partial multi-block break: " + broken + " of " + expected + " expected. Replanning around it.", false);
            }
        }
    }

    private BlockPos cellPos(int idx) {
        Quarry q = model.q;
        return new BlockPos(q.cellX(idx), q.yOfLayer(brain.layer()), q.cellZ(idx));
    }

    private static Vec3d posOf(ClientPlayerEntity p) {
        return new Vec3d(p.getX(), p.getY(), p.getZ());
    }

    private void pickTarget(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, MinerConfig cfg) {
        Quarry q = model.q;
        int before = brain.unavailableCount();
        TargetSelector.Prober prober = autoMode
                ? idx -> autopilot.probe(mc, w, p, cellPos(idx), planFp, cfg)
                : idx -> 0.0;
        MiningBrain.Pick pick = brain.pick(p.getX() - q.minX, p.getZ() - q.minZ, prober);
        int grew = brain.unavailableCount() - before;
        if (grew > 0) {
            notify(Level.INFO, grew + " hard-to-reach block(s) set aside; they get another try at the end of this layer.", false);
        }
        switch (pick.kind) {
            case TARGET -> {
                targetIdx = pick.idx;
                target = cellPos(pick.idx);
                tracker.begin(target, planFp, tick, autoMode);
                targetAssignedTick = tick;
                stuck.reset(posOf(p));
            }
            case RETRY -> hint = brain.inFinalPass() ? "Final try for blocks that were hard to reach..." : "Choosing the next block...";
            case NOTHING -> hint = "Layer looks clear - double-checking...";
            case REPLAN -> {
                planFp = null;
                state = MinerState.PLANNING;
            }
            case NEED_SINGLE_TOOL -> {
                waitingForSingle = true;
                singleReason = "Swap to a normal 1-block pickaxe for " + pick.count + " edge block(s): the "
                        + (planProfile != null ? planProfile.displayName : "current pickaxe")
                        + " would break blocks outside your quarry (or set allowOvershoot in the config).";
                pause(singleReason, true);
            }
            case GAVE_UP -> notify(Level.WARN, "Gave up on " + pick.count + " block(s) in layer " + (brain.layer() + 1)
                    + " after " + cfg.maxReplans + " replans. /miner retry restores them.", true);
        }
    }

    private void deferTarget(MinecraftClient mc, String why) {
        int idx = targetIdx;
        BlockPos t = target;
        dropTarget(mc);
        if (idx >= 0) {
            boolean permanent = brain.defer(idx);
            notify(Level.WARN, (permanent ? "Gave up on " : "Setting aside ") + t.getX() + " " + t.getY() + " " + t.getZ()
                    + ": " + why + (permanent ? "." : "; it gets another try at the end of the layer."), false);
        }
    }

    private void guidance(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, MinerConfig cfg) {
        if (!w.getChunkManager().isChunkLoaded(target.getX() >> 4, target.getZ() >> 4)) {
            chunkWait++;
            state = MinerState.RECOVERING;
            hint = "Waiting for the target chunk to load...";
            if (autoMode) {
                autopilot.releaseAll(mc);
                tracker.hold();
            }
            if (chunkWait > 600) {
                chunkWait = 0;
                pause("Chunks near the target aren't loading (lag or connection problem?). Use /miner resume when it recovers.", false);
            }
            return;
        }
        chunkWait = 0;
        if (autoMode) {
            autoGuidance(mc, w, p, cfg);
            return;
        }
        Vec3d eye = p.getEyePos();
        double dist = ReachGuide.distance(eye, target);
        if (dist > cfg.reach) {
            state = MinerState.MOVING;
            hint = ReachGuide.moveHint(eye, target, dist, cfg.reach);
            if (stuck.update(posOf(p)) >= 600) {
                model.observe(target.getX(), target.getY(), target.getZ(), CellState.SKIPPED);
                tracker.cancel();
                target = null;
                targetIdx = -1;
                notify(Level.WARN, "Target out of reach for 30 s - skipped it. /miner retry restores skipped blocks.", false);
            }
        } else {
            stuck.reset(posOf(p));
            BlockHitResult hit = ReachGuide.blockHit(mc);
            if (hit == null || !hit.getBlockPos().equals(target)) {
                state = MinerState.POSITIONING;
                hint = "In reach - aim at the highlighted block.";
            } else {
                state = MinerState.MINING;
                hint = ReachGuide.mineHint(hit, planProfile);
            }
        }
    }

    private void autoGuidance(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, MinerConfig cfg) {
        String where = target.getX() + " " + target.getY() + " " + target.getZ();
        if (!ToolSelector.anyUsable(p, w.getBlockState(target), cfg)) {
            String name = w.getBlockState(target).getBlock().getName().getString();
            pause("No suitable tool with durability in your hotbar for " + name + ". Put a pickaxe in the hotbar, then /miner resume.", false);
            return;
        }
        AutoPilot.Result r = autopilot.tick(mc, w, p, target, planFp, cfg);
        hint = autopilot.status();
        switch (r) {
            case MINING -> {
                state = MinerState.MINING;
                tracker.noteMining();
                unreachableStreak = 0;
            }
            case POSITIONING, WAITING -> {
                state = MinerState.POSITIONING;
                tracker.hold();
            }
            case WALKING -> {
                state = MinerState.MOVING;
                tracker.hold();
            }
            case UNREACHABLE -> {
                int idx = targetIdx;
                boolean permanent = brain.defer(idx);
                dropTarget(mc);
                unreachableStreak++;
                notify(Level.WARN, permanent ? "Gave up on " + where + " (not reachable)."
                        : "Can't reach " + where + " yet - set aside, retried at the end of the layer.", false);
                if (unreachableStreak >= 6) {
                    unreachableStreak = 0;
                    pause("Can't find anywhere to stand near the next blocks. Clear the space above the top layer "
                            + "or build a ramp, then /miner resume.", false);
                }
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ notifications

    public void notify(Level level, String text, boolean chat) {
        MinerConfig cfg = MinerConfig.get();
        notes.addLast(new Note(text, level, tick + cfg.notificationSeconds * 20L));
        while (notes.size() > 5) {
            notes.pollFirst();
        }
        if (chat) {
            ClientPlayerEntity p = MinecraftClient.getInstance().player;
            if (p != null) {
                p.sendMessage(Text.literal("[Miner] " + text), false);
            }
        }
    }

    public void warn(String text) {
        notify(Level.WARN, text, true);
    }

    // ------------------------------------------------------------------ profile selection

    public String profileOverride() {
        return profileOverride;
    }

    public void setProfileOverride(String id) {
        profileOverride = id;
    }

    public void cycleProfile() {
        List<String> ids = new ArrayList<>();
        ids.add("auto");
        for (PickaxeProfile pr : PickaxeProfiles.all()) {
            ids.add(pr.id);
        }
        int i = ids.indexOf(profileOverride);
        profileOverride = ids.get((i + 1) % ids.size());
    }

    // ------------------------------------------------------------------ getters for UI / render

    public MinerState state() {
        return state;
    }

    public String pauseReason() {
        return pauseReason;
    }

    public Quarry quarry() {
        return quarry;
    }

    public BlockPos pos1() {
        return pos1;
    }

    public BlockPos pos2() {
        return pos2;
    }

    public QuarryModel model() {
        return model;
    }

    public int layer() {
        return brain != null ? Math.max(0, brain.layer()) : 0;
    }

    public BlockPos target() {
        return target;
    }

    public String hint() {
        return hint;
    }

    public PickaxeProfile profile() {
        return profile;
    }

    public PickaxeProfile planProfile() {
        return planProfile;
    }

    public MiningStats stats() {
        return stats;
    }

    public long now() {
        return tick;
    }

    public Calibrator calibrator() {
        return calibrator;
    }

    public List<Note> notes() {
        return new ArrayList<>(notes);
    }

    public boolean hasNotes() {
        return !notes.isEmpty();
    }

    public int[][] planFootprint() {
        return planFp != null ? planFp : new int[][]{{0, 0, 0}};
    }

    public boolean isAutoMode() {
        return autoMode;
    }

    public String modeNote() {
        return modeNote;
    }

    public int unavailableCount() {
        return brain != null ? brain.unavailableCount() : 0;
    }

    public List<int[]> autopilotPath() {
        List<int[]> p = autopilot.path();
        return p == null ? new ArrayList<>() : new ArrayList<>(p);
    }

    /** What the navigation/mining layer is doing right now, in words. */
    public String navStatus() {
        if (!isActive()) {
            return "";
        }
        return autoMode ? autopilot.status() : hint;
    }

    /** "ring 3/12" for the current target (0 = the middle of the layer), or "". */
    public String ringLabel() {
        if (brain == null || brain.plan() == null || target == null || targetIdx < 0) {
            return "";
        }
        return "ring " + brain.plan().ringOf(targetIdx) + "/" + brain.plan().ringMax();
    }

    public String toolLabel(MinecraftClient mc) {
        if (mc.player == null) {
            return "";
        }
        ItemStack held = mc.player.getMainHandStack();
        if (held.isEmpty()) {
            return "empty hand";
        }
        int left = InventoryMonitor.usesLeft(held);
        String name = held.getName().getString();
        return left == Integer.MAX_VALUE ? name : name + " (" + left + " uses)";
    }

    public List<BlockPos> upcomingTargets(int n) {
        List<BlockPos> out = new ArrayList<>();
        if (brain != null && brain.plan() != null && model != null && isActive() && state != MinerState.PAUSED) {
            for (int idx : brain.plan().upcoming(n)) {
                out.add(cellPos(idx));
            }
        }
        return out;
    }

    public List<String> statusLines() {
        List<String> out = new ArrayList<>();
        out.add("Mode: " + (autoMode ? "AUTONOMOUS" : "manual-confirmation")
                + (autoMode || modeNote.isEmpty() ? "" : " (" + modeNote + ")"));
        out.add("State: " + state + (state == MinerState.PAUSED ? " - " + pauseReason : "")
                + (state == MinerState.ERROR ? " - " + errorMessage : ""));
        if (quarry == null) {
            out.add("Quarry: not set. Use /miner pos1 and /miner pos2.");
            return out;
        }
        out.add("Quarry: " + quarry.describe());
        if (model != null) {
            int l = layer();
            out.add("Layer: " + (l + 1) + " / " + model.layers.length + "  (y = " + quarry.yOfLayer(l) + ")"
                    + (ringLabel().isEmpty() ? "" : "  " + ringLabel()));
            out.add(String.format("Mined: %,d    Remaining: %,d    Progress: %.1f%%",
                    model.cleared, model.remainingTotal(), model.percent()));
            if (model.blockedTotal() > 0 || model.skippedTotal() > 0 || model.unknownTotal() > 0 || unavailableCount() > 0) {
                out.add("Wrong tool: " + model.blockedTotal() + "   Skipped: " + model.skippedTotal()
                        + "   Set aside: " + unavailableCount() + "   Not loaded/unscanned: " + model.unknownTotal());
            }
            out.add(String.format("Speed: %.0f blocks/min (last 60 s)", stats.blocksPerMinute(tick)));
        }
        PickaxeProfile pr = profile;
        out.add("Pickaxe profile: " + (pr != null ? pr.label() : "none held") + "   (mode: " + profileOverride + ")");
        if (target != null) {
            out.add("Target: " + target.getX() + " " + target.getY() + " " + target.getZ());
        }
        if (!navStatus().isEmpty()) {
            out.add("Doing: " + navStatus());
        }
        return out;
    }

    public double scanProgress() {
        return scanner == null ? 1.0 : scanner.progress();
    }
}
