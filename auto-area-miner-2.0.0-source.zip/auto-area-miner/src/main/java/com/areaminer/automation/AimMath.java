package com.areaminer.automation;

/** Minecraft yaw/pitch conventions: yaw 0 = south (+Z), 90 = west, -90 = east; positive pitch looks down. */
public final class AimMath {
    private AimMath() {
    }

    public static float yawTo(double dx, double dz) {
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    public static float pitchTo(double dx, double dy, double dz) {
        return (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
    }

    /** Wraps an angle difference into [-180, 180). */
    public static float wrap(float a) {
        a = a % 360.0f;
        if (a >= 180.0f) {
            a -= 360.0f;
        }
        if (a < -180.0f) {
            a += 360.0f;
        }
        return a;
    }
}
