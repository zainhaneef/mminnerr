package com.areaminer.automation;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Terrain backed by the real client world. Unloaded chunks count as solid and unusable. */
public final class WorldTerrain implements Terrain {
    private final ClientWorld world;
    private final BlockPos.Mutable pos = new BlockPos.Mutable();

    public WorldTerrain(ClientWorld world) {
        this.world = world;
    }

    private boolean loaded(int x, int z) {
        return world.getChunkManager().isChunkLoaded(x >> 4, z >> 4);
    }

    static boolean hazard(BlockState s) {
        return s.isOf(Blocks.LAVA) || s.isOf(Blocks.FIRE) || s.isOf(Blocks.SOUL_FIRE)
                || s.isOf(Blocks.MAGMA_BLOCK) || s.isOf(Blocks.CACTUS) || s.isOf(Blocks.COBWEB)
                || s.isOf(Blocks.SWEET_BERRY_BUSH) || s.isOf(Blocks.POWDER_SNOW)
                || s.isOf(Blocks.CAMPFIRE) || s.isOf(Blocks.SOUL_CAMPFIRE) || s.isOf(Blocks.WITHER_ROSE);
    }

    @Override
    public boolean passable(int x, int y, int z) {
        if (!loaded(x, z) || y < world.getBottomY()) {
            return false;
        }
        pos.set(x, y, z);
        BlockState s = world.getBlockState(pos);
        if (!s.getFluidState().isEmpty() || hazard(s)) {
            return false;
        }
        return s.getCollisionShape(world, pos).isEmpty();
    }

    @Override
    public boolean solidFloor(int x, int y, int z) {
        if (!loaded(x, z) || y < world.getBottomY()) {
            return false;
        }
        pos.set(x, y, z);
        BlockState s = world.getBlockState(pos);
        if (hazard(s) || !s.getFluidState().isEmpty()) {
            return false;
        }
        return s.isSideSolidFullSquare(world, pos, Direction.UP);
    }
}
