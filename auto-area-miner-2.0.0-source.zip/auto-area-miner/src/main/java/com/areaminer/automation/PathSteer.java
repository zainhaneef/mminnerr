package com.areaminer.automation;

import java.util.List;

/** Pure helpers for steering along a path without cutting corners. */
public final class PathSteer {
    private PathSteer() {
    }

    /**
     * Index of the node to look towards: the farthest node within {@code lookDist} that continues in a
     * straight line at the same height from node {@code idx}. Never looks across a turn or a step, so the
     * player never cuts a corner into a wall.
     */
    public static int carrot(List<int[]> path, int idx, double px, double pz, double lookDist) {
        int best = idx;
        if (idx >= path.size() - 1) {
            return idx;
        }
        int[] a = path.get(idx);
        int[] b = path.get(idx + 1);
        int dx = b[0] - a[0];
        int dz = b[2] - a[2];
        if (b[1] != a[1] || Math.abs(dx) + Math.abs(dz) != 1) {
            return idx;
        }
        for (int j = idx + 1; j < path.size(); j++) {
            int[] prev = path.get(j - 1);
            int[] cur = path.get(j);
            if (cur[1] != a[1] || cur[0] - prev[0] != dx || cur[2] - prev[2] != dz) {
                break;
            }
            if (Math.hypot(cur[0] + 0.5 - px, cur[2] + 0.5 - pz) > lookDist) {
                break;
            }
            best = j;
        }
        return best;
    }
}
