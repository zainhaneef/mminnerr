package com.areaminer.automation;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Finds points on the target block that are genuinely visible and in reach, using the same outline
 * ray casting the game uses for its crosshair. The top face is preferred (it keeps a flat multi-block
 * pattern inside the layer); among valid points the one needing the least camera movement wins, which
 * keeps the view calm.
 */
public final class AimPlanner {
    private static final double[][] TOP_GRID = {
            {0.5, 0.98, 0.5}, {0.25, 0.98, 0.5}, {0.75, 0.98, 0.5}, {0.5, 0.98, 0.25}, {0.5, 0.98, 0.75},
            {0.25, 0.98, 0.25}, {0.75, 0.98, 0.25}, {0.25, 0.98, 0.75}, {0.75, 0.98, 0.75}};
    private static final double[][] SIDE_GRID = {
            {0.5, 0.6, 0.02}, {0.25, 0.6, 0.02}, {0.75, 0.6, 0.02},
            {0.5, 0.6, 0.98}, {0.25, 0.6, 0.98}, {0.75, 0.6, 0.98},
            {0.02, 0.6, 0.5}, {0.02, 0.6, 0.25}, {0.02, 0.6, 0.75},
            {0.98, 0.6, 0.5}, {0.98, 0.6, 0.25}, {0.98, 0.6, 0.75},
            {0.5, 0.02, 0.5}};
    private static final double[][] QUICK = {
            {0.5, 0.98, 0.5}, {0.5, 0.6, 0.02}, {0.5, 0.6, 0.98}, {0.02, 0.6, 0.5}, {0.98, 0.6, 0.5}};

    private static final double SIDE_PENALTY_DEGREES = 10.0;

    private AimPlanner() {
    }

    /** One ray cast: can {@code eye} see {@code point} on the target block, within reach? */
    public static boolean visible(ClientWorld world, Entity viewer, Vec3d eye, BlockPos target, Vec3d point, double maxDist) {
        if (eye.distanceTo(point) > maxDist) {
            return false;
        }
        BlockHitResult hit = world.raycast(new RaycastContext(eye, point,
                RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, viewer));
        return hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(target);
    }

    private static Vec3d at(BlockPos t, double[] o) {
        return new Vec3d(t.getX() + o[0], t.getY() + o[1], t.getZ() + o[2]);
    }

    /** Cheap check used while searching for places to stand: a handful of points, first visible wins. */
    public static Vec3d quick(ClientWorld world, Entity viewer, Vec3d eye, BlockPos target, boolean topOnly, double maxDist) {
        int n = topOnly ? 1 : QUICK.length;
        for (int i = 0; i < n; i++) {
            Vec3d v = at(target, QUICK[i]);
            if (visible(world, viewer, eye, target, v, maxDist)) {
                return v;
            }
        }
        return null;
    }

    /**
     * Full search, ordered by how little the camera has to move from {@code look} (a unit vector).
     * {@code skip} selects the next-best point when an earlier one failed in practice.
     */
    public static Vec3d best(ClientWorld world, Entity viewer, Vec3d eye, BlockPos target, boolean topOnly,
                             double maxDist, Vec3d look, int skip) {
        List<Vec3d> points = new ArrayList<>();
        List<Double> scores = new ArrayList<>();
        collect(world, viewer, eye, target, TOP_GRID, 0.0, maxDist, look, points, scores);
        if (!topOnly) {
            collect(world, viewer, eye, target, SIDE_GRID, SIDE_PENALTY_DEGREES, maxDist, look, points, scores);
        }
        if (points.isEmpty()) {
            return null;
        }
        Integer[] order = new Integer[points.size()];
        for (int i = 0; i < order.length; i++) {
            order[i] = i;
        }
        java.util.Arrays.sort(order, (a, b) -> Double.compare(scores.get(a), scores.get(b)));
        return points.get(order[Math.floorMod(skip, order.length)]);
    }

    private static void collect(ClientWorld world, Entity viewer, Vec3d eye, BlockPos t, double[][] grid,
                                double penalty, double maxDist, Vec3d look, List<Vec3d> points, List<Double> scores) {
        for (double[] o : grid) {
            Vec3d v = at(t, o);
            if (!visible(world, viewer, eye, t, v, maxDist)) {
                continue;
            }
            Vec3d dir = v.subtract(eye).normalize();
            double dot = Math.max(-1.0, Math.min(1.0, dir.dotProduct(look)));
            points.add(v);
            scores.add(Math.toDegrees(Math.acos(dot)) + penalty);
        }
    }
}
