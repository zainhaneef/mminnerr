package com.areaminer.automation;

/** What the path finder needs to know about the world. Kept tiny so it can be tested without Minecraft. */
public interface Terrain {
    /** An entity (1 wide, 2 tall) can occupy this cell: no collision, no fluid, not hazardous. */
    boolean passable(int x, int y, int z);

    /** The top of this cell is a solid, safe surface to stand on. */
    boolean solidFloor(int x, int y, int z);
}
