package com.areaminer.automation;

import com.areaminer.config.MinerConfig;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Turns the player's camera by changing the player's own yaw/pitch, with limited speed and
 * acceleration (see AimSmoother). It brakes before the target, never overshoots, and keeps its
 * velocity when the target changes, so the view swings smoothly instead of snapping. No packets are
 * involved: the game sends the rotation exactly as it does for mouse movement.
 */
public final class AimController {
    private final AimSmoother yaw = new AimSmoother();
    private final AimSmoother pitch = new AimSmoother();

    public void reset() {
        yaw.reset();
        pitch.reset();
    }

    /** @return remaining angular error in degrees after this step. */
    public double turnTo(ClientPlayerEntity p, float targetYaw, float targetPitch,
                         double maxSpeed, double accel, double stiffness) {
        double errYaw = AimMath.wrap(targetYaw - p.getYaw());
        double errPitch = targetPitch - p.getPitch();
        double dYaw = yaw.step(errYaw, maxSpeed, accel, stiffness);
        double dPitch = pitch.step(errPitch, maxSpeed * 0.75, accel * 0.75, stiffness);
        // yaw stays continuous (350 -> 370, never 350 -> 10) so the renderer's interpolation never spins the view
        p.setYaw(p.getYaw() + (float) dYaw);
        p.setPitch(MathHelper.clamp(p.getPitch() + (float) dPitch, -90.0f, 90.0f));
        return Math.hypot(AimMath.wrap(targetYaw - p.getYaw()), targetPitch - p.getPitch());
    }

    /** Aim at a world point with the configured camera feel. */
    public double turnAim(ClientPlayerEntity p, Vec3d point, MinerConfig cfg) {
        Vec3d eye = p.getEyePos();
        double dx = point.x - eye.x;
        double dy = point.y - eye.y;
        double dz = point.z - eye.z;
        float targetYaw = Math.hypot(dx, dz) < 0.05 ? p.getYaw() : AimMath.yawTo(dx, dz); // straight down: keep yaw
        return turnTo(p, targetYaw, AimMath.pitchTo(dx, dy, dz), cfg.aimMaxSpeed, cfg.aimAcceleration, cfg.aimStiffness);
    }

    /** Gentler turning while walking. */
    public double turnWalk(ClientPlayerEntity p, float targetYaw, float targetPitch, MinerConfig cfg) {
        return turnTo(p, targetYaw, targetPitch, cfg.walkTurnSpeed, Math.min(cfg.aimAcceleration, 3.0), 0.2);
    }
}
