package com.areaminer.automation;

import com.areaminer.config.MinerConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;

import java.util.Locale;

/**
 * Decides whether autonomous walking/aiming/mining may run right now.
 * Default: singleplayer only. DonutSMP addresses are refused unconditionally.
 */
public final class AutomationGate {
    private AutomationGate() {
    }

    /** @return null when automation is allowed, otherwise the reason it is not. */
    public static String check(MinecraftClient mc) {
        MinerConfig cfg = MinerConfig.get();
        if (!cfg.autonomous) {
            return "autonomous mode is switched off (/miner mode auto)";
        }
        ServerInfo info = mc.getCurrentServerEntry();
        if (info != null && info.address != null && info.address.toLowerCase(Locale.ROOT).contains("donut")) {
            return "autonomous mode is permanently disabled on DonutSMP";
        }
        if (mc.isInSingleplayer()) {
            return null;
        }
        if (cfg.allowPrivateServers) {
            return null;
        }
        return "autonomous mode only runs in singleplayer (allowPrivateServers in the config is only for servers where you have permission)";
    }
}
