package com.areaminer.automation;

/**
 * One axis of camera motion with limited speed and acceleration. It brakes early enough to stop
 * exactly on the target (no overshoot, no oscillation) and keeps its velocity when the target moves,
 * so re-targeting curves smoothly instead of snapping.
 */
public final class AimSmoother {
    private double vel;

    public double velocity() {
        return vel;
    }

    public void reset() {
        vel = 0.0;
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /**
     * @param err        signed error in degrees (target - current)
     * @param maxSpeed   degrees per tick
     * @param accel      degrees per tick per tick
     * @param stiffness  fraction of the error asked for each tick (higher = snappier)
     * @return degrees to rotate this tick
     */
    public double step(double err, double maxSpeed, double accel, double stiffness) {
        double abs = Math.abs(err);
        if (abs < 0.05 && Math.abs(vel) < 0.3) {
            vel = 0.0;
            return err;
        }
        double desired = clamp(err * stiffness, -maxSpeed, maxSpeed);
        double brake = Math.sqrt(2.0 * accel * abs); // fastest speed that can still stop within |err|
        desired = clamp(desired, -brake, brake);
        vel += clamp(desired - vel, -accel, accel);
        double delta = vel;
        if (Math.signum(delta) == Math.signum(err) && Math.abs(delta) > abs) {
            delta = err; // arrive exactly instead of overshooting
            vel = 0.0;
        }
        return delta;
    }
}
