package com.areaminer.automation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * A* over "feet cells". A cell is standable when feet and head cells are passable and the cell
 * below is a solid floor. Moves: walk to a neighbour, jump up one block, or step off and drop up to
 * three blocks. No parkour, no swimming, no diagonals. The search is capped so it can never hang.
 */
public final class Pathfinder {
    public interface Goal {
        /** Cells the search may use at all (e.g. not below the layer being mined). */
        boolean allowed(int x, int y, int z);

        boolean reached(int x, int y, int z);

        /** Optimistic distance still to go (0 when unknown). */
        double estimate(int x, int y, int z);
    }

    private static final class Node implements Comparable<Node> {
        final int x;
        final int y;
        final int z;
        final double g;
        final double f;
        final Node parent;

        Node(int x, int y, int z, double g, double f, Node parent) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.g = g;
            this.f = f;
            this.parent = parent;
        }

        @Override
        public int compareTo(Node o) {
            return Double.compare(f, o.f);
        }
    }

    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private static final int MAX_DROP = 3;

    private Pathfinder() {
    }

    public static long key(int x, int y, int z) {
        return (((long) x & 0x3FFFFFFL) << 38) | (((long) z & 0x3FFFFFFL) << 12) | ((long) y & 0xFFFL);
    }

    public static boolean standable(Terrain t, int x, int y, int z) {
        return t.passable(x, y, z) && t.passable(x, y + 1, z) && t.solidFloor(x, y - 1, z);
    }

    /** @return cells from the start (inclusive) to the goal (inclusive), or null when nothing was found. */
    public static List<int[]> find(Terrain t, int sx, int sy, int sz, Goal goal, int maxNodes) {
        PriorityQueue<Node> open = new PriorityQueue<>();
        Map<Long, Node> best = new HashMap<>();
        Node start = new Node(sx, sy, sz, 0, goal.estimate(sx, sy, sz), null);
        open.add(start);
        best.put(key(sx, sy, sz), start);
        int expanded = 0;
        while (!open.isEmpty() && expanded < maxNodes) {
            Node n = open.poll();
            if (best.get(key(n.x, n.y, n.z)) != n) {
                continue; // a cheaper route to this cell was found later
            }
            if (goal.reached(n.x, n.y, n.z)) {
                return build(n);
            }
            expanded++;
            for (int[] d : DIRS) {
                int nx = n.x + d[0];
                int nz = n.z + d[1];
                if (!t.passable(nx, n.y, nz)) {
                    // blocked at foot level: try jumping up one block
                    if (t.passable(n.x, n.y + 2, n.z) && standable(t, nx, n.y + 1, nz)) {
                        relax(open, best, goal, n, nx, n.y + 1, nz, 2.0);
                    }
                    continue;
                }
                if (!t.passable(nx, n.y + 1, nz)) {
                    continue; // head would hit something
                }
                if (standable(t, nx, n.y, nz)) {
                    relax(open, best, goal, n, nx, n.y, nz, 1.0);
                } else {
                    // no floor ahead: step off and drop
                    for (int k = 1; k <= MAX_DROP; k++) {
                        int ny = n.y - k;
                        if (!t.passable(nx, ny, nz) || !t.passable(nx, ny + 1, nz)) {
                            break;
                        }
                        if (t.solidFloor(nx, ny - 1, nz)) {
                            relax(open, best, goal, n, nx, ny, nz, 1.0 + 0.5 * k);
                            break;
                        }
                    }
                }
            }
        }
        return null;
    }

    private static void relax(PriorityQueue<Node> open, Map<Long, Node> best, Goal goal,
                              Node from, int x, int y, int z, double cost) {
        if (!goal.allowed(x, y, z)) {
            return;
        }
        double g = from.g + cost;
        long k = key(x, y, z);
        Node existing = best.get(k);
        if (existing == null || g < existing.g) {
            Node nn = new Node(x, y, z, g, g + goal.estimate(x, y, z), from);
            best.put(k, nn);
            open.add(nn);
        }
    }

    private static List<int[]> build(Node end) {
        List<int[]> out = new ArrayList<>();
        for (Node n = end; n != null; n = n.parent) {
            out.add(new int[]{n.x, n.y, n.z});
        }
        Collections.reverse(out);
        return out;
    }
}
