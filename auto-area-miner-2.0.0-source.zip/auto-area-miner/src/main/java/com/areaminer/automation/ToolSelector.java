package com.areaminer.automation;

import com.areaminer.config.MinerConfig;
import com.areaminer.inventory.InventoryMonitor;
import com.areaminer.pickaxe.PickaxeProfiles;
import net.minecraft.block.BlockState;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;

/**
 * Switches hotbar slots (a normal client action) only when the held item is clearly a poor
 * choice for the block. A held tool that works reasonably is never swapped, so the pickaxe
 * profile does not flip back and forth.
 */
public final class ToolSelector {
    private ToolSelector() {
    }

    private static boolean usable(ItemStack s, BlockState state, MinerConfig cfg) {
        if (s.isEmpty()) {
            return false;
        }
        if (state.isToolRequired() && !s.isSuitableFor(state)) {
            return false;
        }
        return InventoryMonitor.usesLeft(s) > cfg.lowDurabilityUses;
    }

    public static void ensureTool(ClientPlayerEntity p, BlockState state, MinerConfig cfg) {
        if (!cfg.autoSelectTool) {
            return;
        }
        PlayerInventory inv = p.getInventory();
        int current = inv.getSelectedSlot();
        ItemStack held = inv.getStack(current);
        float heldSpeed = usable(held, state, cfg) ? held.getMiningSpeedMultiplier(state) : 0.0f;
        int best = -1;
        float bestSpeed = 0.0f;
        for (int i = 0; i < 9; i++) {
            ItemStack s = inv.getStack(i);
            if (!usable(s, state, cfg)) {
                continue;
            }
            float speed = s.getMiningSpeedMultiplier(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                best = i;
            }
        }
        if (best >= 0 && best != current && heldSpeed < bestSpeed * 0.6f) {
            inv.setSelectedSlot(best);
        }
    }

    /** Switches to another hotbar mining tool that still has durability. @return true if a swap happened. */
    public static boolean swapAwayFromLowDurability(ClientPlayerEntity p, MinerConfig cfg) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack s = inv.getStack(i);
            if (PickaxeProfiles.isMiningTool(s) && InventoryMonitor.usesLeft(s) > cfg.lowDurabilityUses) {
                inv.setSelectedSlot(i);
                return true;
            }
        }
        return false;
    }

    /** True when some hotbar item can mine this block at all. */
    public static boolean anyUsable(ClientPlayerEntity p, BlockState state, MinerConfig cfg) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 9; i++) {
            if (usable(inv.getStack(i), state, cfg)) {
                return true;
            }
        }
        return false;
    }
}
