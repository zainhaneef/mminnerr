package com.areaminer.automation;

import com.areaminer.config.MinerConfig;
import com.areaminer.recovery.StuckDetector;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Follows a path by pressing forward/jump and turning the camera.
 * - Looks ahead along straight stretches and holds its heading when it is on top of a waypoint, so the
 *   view no longer whips around while passing node centres (a 1.1.0 problem).
 * - Re-validates the next few cells every tick and re-plans when the world changed.
 * - Stuck recovery escalates: hop, then ban the blocking cell and re-plan, then give up (bounded).
 */
public final class Navigator {
    public enum Status { WALKING, ARRIVED, FAILED }

    private final StuckDetector stuck = new StuckDetector();
    private final Set<Long> avoid = new HashSet<>();
    private List<int[]> path;
    private int idx;
    private int stuckStage;
    private int repaths;
    private int ticks;
    private int airTicks;
    private int forceJump;
    private float yawTarget;
    private boolean haveYaw;
    private String status = "idle";

    public void reset() {
        path = null;
        idx = 0;
        stuckStage = 0;
        repaths = 0;
        ticks = 0;
        airTicks = 0;
        forceJump = 0;
        haveYaw = false;
        avoid.clear();
        status = "idle";
    }

    public List<int[]> path() {
        return path;
    }

    public String status() {
        return status;
    }

    private static Vec3d pos(ClientPlayerEntity p) {
        return new Vec3d(p.getX(), p.getY(), p.getZ());
    }

    private Status repath(MinecraftClient mc, InputDriver in, MinerConfig cfg, String why) {
        path = null;
        repaths++;
        status = "re-planning (" + why + ")";
        if (repaths > cfg.maxRepaths) {
            in.stopMoving(mc);
            status = "gave up: " + why;
            return Status.FAILED;
        }
        return Status.WALKING;
    }

    private final class AvoidingGoal implements Pathfinder.Goal {
        private final Pathfinder.Goal inner;

        AvoidingGoal(Pathfinder.Goal inner) {
            this.inner = inner;
        }

        @Override
        public boolean allowed(int x, int y, int z) {
            return !avoid.contains(Pathfinder.key(x, y, z)) && inner.allowed(x, y, z);
        }

        @Override
        public boolean reached(int x, int y, int z) {
            return inner.reached(x, y, z);
        }

        @Override
        public double estimate(int x, int y, int z) {
            return inner.estimate(x, y, z);
        }
    }

    public Status tick(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, Pathfinder.Goal goal,
                       AimController aim, InputDriver in, MinerConfig cfg) {
        ticks++;
        if (ticks > cfg.walkTimeoutSeconds * 20) {
            in.stopMoving(mc);
            status = "gave up: took too long";
            return Status.FAILED;
        }
        Terrain terrain = new WorldTerrain(w);
        int fx = MathHelper.floor(p.getX());
        int fy = MathHelper.floor(p.getY() + 0.001);
        int fz = MathHelper.floor(p.getZ());

        if (path == null) {
            if (!p.isOnGround()) {
                in.stopMoving(mc);
                airTicks++;
                status = "waiting to land";
                return airTicks > 100 ? Status.FAILED : Status.WALKING;
            }
            airTicks = 0;
            path = Pathfinder.find(terrain, fx, fy, fz, avoid.isEmpty() ? goal : new AvoidingGoal(goal), cfg.pathNodeLimit);
            if (path == null) {
                in.stopMoving(mc);
                status = "no route found";
                return Status.FAILED;
            }
            idx = path.size() == 1 ? 0 : 1;
            stuck.reset(pos(p));
            stuckStage = 0;
        }

        Vec3d vel = p.getVelocity();
        double speed = Math.hypot(vel.x, vel.z);

        // consume every node we are already standing on
        while (true) {
            int[] n = path.get(idx);
            boolean last = idx == path.size() - 1;
            double hd = Math.hypot(n[0] + 0.5 - p.getX(), n[2] + 0.5 - p.getZ());
            boolean levelOk = Math.abs(p.getY() - n[1]) < 0.9;
            if (hd < (last ? 0.3 : 0.35) && levelOk && p.isOnGround()) {
                if (last) {
                    in.stopMoving(mc);
                    status = "in position";
                    return speed < 0.03 ? Status.ARRIVED : Status.WALKING;
                }
                idx++;
                stuck.reset(pos(p));
                continue;
            }
            break;
        }

        // the next few cells must still be standable (the world may have changed under the plan)
        for (int j = idx; j < Math.min(path.size(), idx + 3); j++) {
            int[] c = path.get(j);
            if (!Pathfinder.standable(terrain, c[0], c[1], c[2])) {
                return repath(mc, in, cfg, "path changed");
            }
        }

        int[] n = path.get(idx);
        boolean last = idx == path.size() - 1;
        double dx = n[0] + 0.5 - p.getX();
        double dz = n[2] + 0.5 - p.getZ();
        double hd = Math.hypot(dx, dz);

        // steering: look along the straight stretch ahead; hold the heading when on top of a waypoint
        int ci = PathSteer.carrot(path, idx, p.getX(), p.getZ(), 2.2);
        int[] carrot = path.get(ci);
        double lx = carrot[0] + 0.5 - p.getX();
        double lz = carrot[2] + 0.5 - p.getZ();
        if (Math.hypot(lx, lz) > 0.45) {
            yawTarget = AimMath.yawTo(lx, lz);
            haveYaw = true;
        }
        if (haveYaw) {
            aim.turnWalk(p, yawTarget, 8.0f, cfg);
        }
        boolean aligned = !haveYaw || Math.abs(AimMath.wrap(yawTarget - p.getYaw())) < 30.0;

        boolean forward = aligned && (!last || hd > 0.5 || (hd > 0.3 && speed < 0.03));
        in.forward(mc, forward);

        boolean stepUp = n[1] > fy;
        boolean jump = (stepUp && p.isOnGround() && hd < 1.6) || forceJump > 0;
        if (forceJump > 0) {
            forceJump--;
        }
        in.jump(mc, jump);
        status = "walking (" + (path.size() - idx) + " steps)";

        if (forward) {
            if (stuck.update(pos(p)) >= 25) {
                stuck.reset(pos(p));
                stuckStage++;
                if (stuckStage == 1) {
                    forceJump = 6; // first remedy: hop
                    status = "stuck - hopping";
                } else {
                    avoid.add(Pathfinder.key(n[0], n[1], n[2])); // second: that cell doesn't work, plan around it
                    return repath(mc, in, cfg, "stuck");
                }
            }
        } else {
            stuck.reset(pos(p));
        }
        return Status.WALKING;
    }
}
