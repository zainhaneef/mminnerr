package com.areaminer.automation;

import net.minecraft.client.MinecraftClient;

/**
 * Presses the player's own key bindings (forward, jump, attack) exactly as if the keys were held.
 * The game then moves the player and breaks blocks through its normal code paths.
 * Keys are re-asserted every tick and always released on stop/pause/disconnect.
 */
public final class InputDriver {
    private boolean usedForward;
    private boolean usedJump;
    private boolean usedAttack;

    public void forward(MinecraftClient mc, boolean down) {
        mc.options.forwardKey.setPressed(down);
        usedForward = true;
    }

    public void jump(MinecraftClient mc, boolean down) {
        mc.options.jumpKey.setPressed(down);
        usedJump = true;
    }

    public void attack(MinecraftClient mc, boolean down) {
        mc.options.attackKey.setPressed(down);
        usedAttack = true;
    }

    public void stopMoving(MinecraftClient mc) {
        if (usedForward) {
            mc.options.forwardKey.setPressed(false);
        }
        if (usedJump) {
            mc.options.jumpKey.setPressed(false);
        }
    }

    public void releaseAll(MinecraftClient mc) {
        if (mc == null || mc.options == null) {
            return;
        }
        if (usedForward) {
            mc.options.forwardKey.setPressed(false);
        }
        if (usedJump) {
            mc.options.jumpKey.setPressed(false);
        }
        if (usedAttack) {
            mc.options.attackKey.setPressed(false);
        }
        usedForward = false;
        usedJump = false;
        usedAttack = false;
    }
}
