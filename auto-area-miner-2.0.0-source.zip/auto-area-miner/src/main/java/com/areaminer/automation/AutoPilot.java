package com.areaminer.automation;

import com.areaminer.area.Quarry;
import com.areaminer.config.MinerConfig;
import com.areaminer.movement.ReachGuide;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Performs the actions for one target: walk until the block is in reach and visible, stand still,
 * turn the camera onto it, and hold the attack key while the real crosshair is on the block.
 * Success is never decided here - the MiningTracker watches the world for the block disappearing.
 */
public final class AutoPilot {
    public enum Result { WALKING, POSITIONING, MINING, WAITING, UNREACHABLE, COLLECTING, DONE }

    private final Navigator nav = new Navigator();
    private final AimController aim = new AimController();
    private final InputDriver in = new InputDriver();

    private BlockPos target;
    private final Set<Long> badCells = new HashSet<>();
    private int arrivals;
    private int aimFail;
    private int aimVariant;
    private Vec3d lockedAim;
    private int lockLost;
    private String status = "idle";

    private boolean collecting;
    private int collectTicks;
    private int pickupWait;
    private final Set<Integer> skippedItems = new HashSet<>();

    // ------------------------------------------------------------------ lifecycle

    public void reset(MinecraftClient mc) {
        nav.reset();
        in.releaseAll(mc);
        target = null;
        badCells.clear();
        arrivals = 0;
        aimFail = 0;
        aimVariant = 0;
        lockedAim = null;
        lockLost = 0;
        aim.reset();
        collecting = false;
        collectTicks = 0;
        pickupWait = 0;
        skippedItems.clear();
    }

    public void releaseAll(MinecraftClient mc) {
        in.releaseAll(mc);
    }

    public void stopMining(MinecraftClient mc) {
        in.attack(mc, false);
    }

    /** Call after a target finished (or was dropped) so the next one starts clean. */
    public void onTargetDone(MinecraftClient mc) {
        in.attack(mc, false);
        nav.reset();
        target = null;
        badCells.clear();
        arrivals = 0;
        aimFail = 0;
        aimVariant = 0;
        lockedAim = null;
        lockLost = 0;
        aim.reset();
    }

    public List<int[]> path() {
        return nav.path();
    }

    private void startTarget(BlockPos t) {
        target = t;
        nav.reset();
        badCells.clear();
        arrivals = 0;
        aimFail = 0;
        aimVariant = 0;
        lockedAim = null;
        lockLost = 0;
        aim.reset();
    }

    // ------------------------------------------------------------------ mining

    private static boolean flatMulti(int[][] fp) {
        if (fp.length < 2) {
            return false;
        }
        for (int[] o : fp) {
            if (o[1] != 0) {
                return false;
            }
        }
        return true;
    }

    public String status() {
        return status;
    }

    /** True while the attack key is being held on the target (the tracker only judges the ability then). */
    public boolean isMining() {
        return mining;
    }

    private boolean mining;

    private Vec3d acquireAim(ClientWorld w, ClientPlayerEntity p, Vec3d eye, BlockPos t, boolean topOnly, double reach) {
        if (lockedAim != null) {
            if (AimPlanner.visible(w, p, eye, t, lockedAim, reach)) {
                lockLost = 0;
                return lockedAim;
            }
            if (++lockLost < 3) {
                return lockedAim; // brief flicker: keep the same point instead of swinging to another
            }
            lockedAim = null;
        }
        lockedAim = AimPlanner.best(w, p, eye, t, topOnly, reach, p.getRotationVec(1.0f), aimVariant);
        lockLost = 0;
        return lockedAim;
    }

    /**
     * Cost of getting into position to mine {@code t}: 0 when it can be mined from where we stand,
     * the number of steps otherwise, or -1 when no route to a place with a clear shot exists.
     */
    public double probe(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, BlockPos t, int[][] fp, MinerConfig cfg) {
        boolean topOnly = flatMulti(fp);
        double reach = cfg.reach - cfg.reachMargin;
        if (AimPlanner.quick(w, p, p.getEyePos(), t, topOnly, reach) != null) {
            return 0.0;
        }
        int fx = MathHelper.floor(p.getX());
        int fy = MathHelper.floor(p.getY() + 0.001);
        int fz = MathHelper.floor(p.getZ());
        List<int[]> path = Pathfinder.find(new WorldTerrain(w), fx, fy, fz,
                new ReachGoal(w, p, t, topOnly, reach, new HashSet<>()), cfg.pathNodeLimit);
        return path == null ? -1.0 : path.size();
    }

    public Result tick(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, BlockPos t, int[][] fp, MinerConfig cfg) {
        if (!t.equals(target)) {
            startTarget(t);
        }
        mining = false;
        boolean topOnly = flatMulti(fp);
        BlockState state = w.getBlockState(t);
        ToolSelector.ensureTool(p, state, cfg);

        double reach = cfg.reach - cfg.reachMargin;
        Vec3d eye = p.getEyePos();
        Vec3d aimPoint = acquireAim(w, p, eye, t, topOnly, reach);
        Vec3d vel = p.getVelocity();
        double speed = Math.hypot(vel.x, vel.z);

        if (aimPoint != null) {
            // close enough and visible from where we really are: stop walking and mine
            nav.reset();
            in.stopMoving(mc);
            if (!p.isOnGround() || speed > 0.05) {
                in.attack(mc, false);
                status = "settling";
                return Result.WAITING;
            }
            double err = aim.turnAim(p, aimPoint, cfg);
            if (err > 1.0) {
                in.attack(mc, false);
                status = String.format("aiming (%.0f deg to go)", err);
                return Result.POSITIONING;
            }
            BlockHitResult hit = ReachGuide.blockHit(mc);
            if (hit != null && hit.getBlockPos().equals(t)) {
                aimFail = 0;
                in.attack(mc, true);
                mining = true;
                status = "mining";
                return Result.MINING;
            }
            in.attack(mc, false);
            aimFail++;
            status = "re-aiming";
            if (aimFail > 12) {
                // the crosshair still isn't on the block: try the next-best point; after three, this spot is bad
                aimFail = 0;
                lockedAim = null;
                aimVariant++;
                if (aimVariant % 3 == 0) {
                    badCells.add(Pathfinder.key(MathHelper.floor(p.getX()), MathHelper.floor(p.getY() + 0.001), MathHelper.floor(p.getZ())));
                    nav.reset();
                    arrivals++;
                    if (arrivals > 3) {
                        status = "no clear shot from anywhere";
                        return Result.UNREACHABLE;
                    }
                }
            }
            return Result.POSITIONING;
        }

        // not in reach / not visible from here: walk to a better spot
        lockedAim = null;
        in.attack(mc, false);
        Pathfinder.Goal goal = new ReachGoal(w, p, t, topOnly, reach, badCells);
        Navigator.Status s = nav.tick(mc, w, p, goal, aim, in, cfg);
        status = nav.status();
        if (s == Navigator.Status.FAILED) {
            in.stopMoving(mc);
            return Result.UNREACHABLE;
        }
        if (s == Navigator.Status.ARRIVED) {
            // we stand where the plan said, yet the real eye position has no clear shot: mark the cell bad
            badCells.add(Pathfinder.key(MathHelper.floor(p.getX()), MathHelper.floor(p.getY() + 0.001), MathHelper.floor(p.getZ())));
            nav.reset();
            arrivals++;
            return arrivals > 4 ? Result.UNREACHABLE : Result.WAITING;
        }
        return Result.WALKING;
    }

    private static final class ReachGoal implements Pathfinder.Goal {
        private final ClientWorld w;
        private final ClientPlayerEntity p;
        private final BlockPos t;
        private final boolean topOnly;
        private final double reach;
        private final Set<Long> bad;

        ReachGoal(ClientWorld w, ClientPlayerEntity p, BlockPos t, boolean topOnly, double reach, Set<Long> bad) {
            this.w = w;
            this.p = p;
            this.t = t;
            this.topOnly = topOnly;
            this.reach = reach;
            this.bad = bad;
        }

        @Override
        public boolean allowed(int x, int y, int z) {
            return y >= t.getY() && !bad.contains(Pathfinder.key(x, y, z));
        }

        @Override
        public boolean reached(int x, int y, int z) {
            if (bad.contains(Pathfinder.key(x, y, z))) {
                return false;
            }
            Vec3d eye = new Vec3d(x + 0.5, y + 1.62, z + 0.5);
            if (eye.distanceTo(Vec3d.ofCenter(t)) > reach + 0.9) {
                return false;
            }
            return AimPlanner.quick(w, p, eye, t, topOnly, reach) != null;
        }

        @Override
        public double estimate(int x, int y, int z) {
            double dx = x + 0.5 - (t.getX() + 0.5);
            double dy = y + 1.62 - (t.getY() + 0.5);
            double dz = z + 0.5 - (t.getZ() + 0.5);
            return Math.max(0.0, Math.sqrt(dx * dx + dy * dy + dz * dz) - reach);
        }
    }

    // ------------------------------------------------------------------ picking up drops

    public boolean collecting() {
        return collecting;
    }

    public void beginCollect(MinerConfig cfg) {
        if (!cfg.collectDrops) {
            return;
        }
        collecting = true;
        collectTicks = 0;
        pickupWait = 0;
        skippedItems.clear();
        nav.reset();
    }

    private void finishCollect(MinecraftClient mc) {
        collecting = false;
        in.releaseAll(mc);
        nav.reset();
    }

    /** Walks to nearby dropped items inside the quarry. Bounded by time and by a skip list. */
    public Result collectTick(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p, Quarry q, int layerY, MinerConfig cfg) {
        in.attack(mc, false);
        collectTicks++;
        if (collectTicks > cfg.collectSeconds * 20) {
            finishCollect(mc);
            return Result.DONE;
        }
        Box area = new Box(q.minX - 1, q.minY - 1, q.minZ - 1, q.maxX + 2, q.maxY + 2, q.maxZ + 2);
        Box near = new Box(p.getX() - 8, p.getY() - 6, p.getZ() - 8, p.getX() + 8, p.getY() + 6, p.getZ() + 8);
        List<ItemEntity> items = w.getEntitiesByClass(ItemEntity.class, near,
                e -> e.isAlive() && area.contains(e.getX(), e.getY(), e.getZ()) && !skippedItems.contains(e.getId()));
        if (items.isEmpty()) {
            finishCollect(mc);
            return Result.DONE;
        }
        ItemEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (ItemEntity e : items) {
            double d = e.squaredDistanceTo(p);
            if (d < bestDist) {
                bestDist = d;
                best = e;
            }
        }
        double hd = Math.hypot(best.getX() - p.getX(), best.getZ() - p.getZ());
        double vy = Math.abs(best.getY() - p.getY());
        if (hd < 0.9 && vy < 1.8) {
            in.stopMoving(mc);
            pickupWait++;
            if (pickupWait > 12) { // not being picked up (inventory full, or wrong spot): leave it
                skippedItems.add(best.getId());
                pickupWait = 0;
            }
            return Result.COLLECTING;
        }
        pickupWait = 0;
        Pathfinder.Goal goal = new ItemGoal(best.getX(), best.getY(), best.getZ(), layerY);
        Navigator.Status s = nav.tick(mc, w, p, goal, aim, in, cfg);
        if (s == Navigator.Status.FAILED) {
            skippedItems.add(best.getId());
            nav.reset();
        } else if (s == Navigator.Status.ARRIVED) {
            nav.reset();
            pickupWait++;
        }
        return Result.COLLECTING;
    }

    private static final class ItemGoal implements Pathfinder.Goal {
        private final double ix;
        private final double iy;
        private final double iz;
        private final int minY;

        ItemGoal(double ix, double iy, double iz, int minY) {
            this.ix = ix;
            this.iy = iy;
            this.iz = iz;
            this.minY = minY;
        }

        @Override
        public boolean allowed(int x, int y, int z) {
            return y >= minY;
        }

        @Override
        public boolean reached(int x, int y, int z) {
            return Math.hypot(x + 0.5 - ix, z + 0.5 - iz) <= 0.7 && Math.abs(y - MathHelper.floor(iy)) <= 1;
        }

        @Override
        public double estimate(int x, int y, int z) {
            return Math.hypot(x + 0.5 - ix, z + 0.5 - iz);
        }
    }
}
