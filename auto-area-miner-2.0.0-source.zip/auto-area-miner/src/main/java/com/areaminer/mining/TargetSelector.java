package com.areaminer.mining;

import com.areaminer.pathfinding.LayerPlan;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Picks the next target. Rules, in order of importance:
 *  1. Stay in the innermost ring that still has available work (centre-out, finish a ring first).
 *  2. Within that, prefer the cell closest to the previous target, so the miner sweeps along the
 *     ring instead of hopping between distant blocks.
 *  3. Among the best few, prefer the one that is cheap to get into position for. Candidates the
 *     prober says are unreachable are reported back so the caller can defer them.
 */
public final class TargetSelector {
    /** Cost of getting into position for a cell (>= 0), or a negative number if it can't be reached now. */
    public interface Prober {
        double cost(int cellIdx);
    }

    public static final class Choice {
        public final int idx;
        public final double cost;

        Choice(int idx, double cost) {
            this.idx = idx;
            this.cost = cost;
        }
    }

    private static final double RING_WEIGHT = 40.0; // dominates any in-window distance: finish a ring before the next
    private static final double PROBE_WEIGHT = 0.5;

    private final int window;
    private final int probes;
    private int lastIdx = -1;

    public TargetSelector(int window, int probes) {
        this.window = Math.max(8, window);
        this.probes = Math.max(1, probes);
    }

    public void reset() {
        lastIdx = -1;
    }

    public void noteDone(int idx) {
        lastIdx = idx;
    }

    /**
     * @param refX player x relative to the quarry minimum (used before any target was mined)
     * @param failed receives candidates the prober rejected
     * @return the chosen cell, or null when nothing was chosen this call
     */
    public Choice select(LayerPlan plan, int sizeX, double refX, double refZ, Prober prober,
                         Set<Integer> unavailable, List<Integer> failed) {
        List<Integer> raw = plan.upcoming(window + unavailable.size());
        List<Integer> cands = new ArrayList<>();
        for (int c : raw) {
            if (!unavailable.contains(c) && cands.size() < window) {
                cands.add(c);
            }
        }
        if (cands.isEmpty()) {
            return null;
        }
        int minRing = Integer.MAX_VALUE;
        for (int c : cands) {
            minRing = Math.min(minRing, plan.ringOf(c));
        }
        double rx = lastIdx >= 0 ? lastIdx % sizeX : refX;
        double rz = lastIdx >= 0 ? lastIdx / sizeX : refZ;

        final double[] score = new double[cands.size()];
        Integer[] order = new Integer[cands.size()];
        for (int i = 0; i < cands.size(); i++) {
            int c = cands.get(i);
            double d = Math.hypot(c % sizeX - rx, c / sizeX - rz);
            score[i] = (plan.ringOf(c) - minRing) * RING_WEIGHT + d + i * 0.001;
            order[i] = i;
        }
        java.util.Arrays.sort(order, (a, b) -> Double.compare(score[a], score[b]));

        Choice best = null;
        double bestTotal = Double.MAX_VALUE;
        for (int k = 0; k < Math.min(probes, order.length); k++) {
            int i = order[k];
            int c = cands.get(i);
            double cost = prober.cost(c);
            if (cost < 0) {
                failed.add(c);
                continue;
            }
            double total = score[i] + PROBE_WEIGHT * cost;
            if (total < bestTotal) {
                bestTotal = total;
                best = new Choice(c, cost);
            }
        }
        return best;
    }
}
