package com.areaminer.mining;

import com.areaminer.area.CellState;
import com.areaminer.area.LayerData;
import com.areaminer.area.QuarryModel;
import com.areaminer.pathfinding.LayerPlan;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * All decisions about WHAT to mine next, with no Minecraft dependency (so it can be tested headless):
 * layer sequencing, per-layer plans, centre-out target choice, deferring unreachable blocks, one final
 * retry pass per layer, bounded re-planning and the "needs a 1-block tool" case.
 */
public final class MiningBrain {
    public static final class Params {
        public int window = 64;
        public int probes = 4;
        public int maxReplans = 3;
        public boolean allowOvershoot = false;
        public LayerPlan.Order order = LayerPlan.Order.CENTER_OUT;
    }

    public enum Kind { TARGET, RETRY, NOTHING, REPLAN, NEED_SINGLE_TOOL, GAVE_UP }

    public static final class Pick {
        public final Kind kind;
        public final int idx;
        public final int count;

        Pick(Kind kind, int idx, int count) {
            this.kind = kind;
            this.idx = idx;
            this.count = count;
        }
    }

    private final QuarryModel model;
    private final Params params;
    private final TargetSelector selector;
    private final Set<Integer> unavailable = new HashSet<>();
    private int layer = -1;
    private LayerPlan plan;
    private int[][] planFp;
    private boolean finalPass;
    private int replans;
    private int remainingAtReplan = Integer.MAX_VALUE;

    public MiningBrain(QuarryModel model, Params params) {
        this.model = model;
        this.params = params;
        this.selector = new TargetSelector(params.window, params.probes);
    }

    public int layer() {
        return layer;
    }

    public LayerPlan plan() {
        return plan;
    }

    public int[][] planFp() {
        return planFp;
    }

    public int unavailableCount() {
        return unavailable.size();
    }

    public boolean inFinalPass() {
        return finalPass;
    }

    /** Moves to the next layer that has work. @return false when every layer is done. */
    public boolean enterNextLayer() {
        for (int l = layer + 1; l < model.layers.length; l++) {
            LayerData d = model.layers[l];
            if (d.remaining > 0 || d.unknown > 0) {
                layer = l;
                resetLayerState();
                return true;
            }
        }
        return false;
    }

    private void resetLayerState() {
        plan = null;
        unavailable.clear();
        finalPass = false;
        replans = 0;
        remainingAtReplan = Integer.MAX_VALUE;
        selector.reset();
    }

    public void invalidatePlan() {
        plan = null;
    }

    public boolean hasPlan() {
        return plan != null;
    }

    /** Builds (if needed) and advances the current layer's plan. @return true when planning is finished. */
    public boolean planStep(int[][] footprint, int budget) {
        if (plan == null) {
            planFp = footprint;
            plan = new LayerPlan(model, layer, footprint, params.allowOvershoot, params.order);
        }
        return plan.step(budget);
    }

    public boolean layerClear() {
        LayerData d = model.layers[layer];
        return d.remaining == 0 && d.unknown == 0 && d.confirmedClear;
    }

    public void targetDone(int idx) {
        selector.noteDone(idx);
        replans = 0;
    }

    /** Gives up on a cell for now; on the final pass it is skipped for good. @return true if skipped for good. */
    public boolean defer(int idx) {
        if (finalPass) {
            model.observe(model.q.cellX(idx), model.q.yOfLayer(layer), model.q.cellZ(idx), CellState.SKIPPED);
            return true;
        }
        unavailable.add(idx);
        return false;
    }

    /** Restores deferred cells for another try (used by the stall watchdog). */
    public void clearDeferred() {
        unavailable.clear();
    }

    public Pick pick(double refX, double refZ, TargetSelector.Prober prober) {
        plan.pruneHead();
        List<Integer> failed = new ArrayList<>();
        TargetSelector.Choice c = selector.select(plan, model.q.sizeX(), refX, refZ, prober, unavailable, failed);
        for (int f : failed) {
            defer(f);
        }
        if (c != null) {
            return new Pick(Kind.TARGET, c.idx, 0);
        }
        if (!failed.isEmpty()) {
            return new Pick(Kind.RETRY, -1, 0);
        }

        LayerData d = model.layers[layer];
        if (d.remaining == 0) {
            return new Pick(Kind.NOTHING, -1, 0);
        }
        int avail = 0;
        int deferred = 0;
        for (int i = 0; i < d.size(); i++) {
            if (d.get(i) == CellState.REMAINING) {
                if (unavailable.contains(i)) {
                    deferred++;
                } else {
                    avail++;
                }
            }
        }
        if (avail == 0 && deferred > 0 && !finalPass) {
            finalPass = true;          // one more try for everything that was deferred
            unavailable.clear();
            return new Pick(Kind.RETRY, -1, 0);
        }
        if (avail == 0) {
            return new Pick(Kind.NOTHING, -1, 0);
        }
        // blocks exist that the plan does not cover
        int leftovers = plan.leftoverRemaining();
        if (leftovers > 0 && plan.isMultiBlock() && !params.allowOvershoot && leftovers >= avail) {
            return new Pick(Kind.NEED_SINGLE_TOOL, -1, leftovers);
        }
        if (avail < remainingAtReplan) {
            replans = 0;
        }
        remainingAtReplan = avail;
        if (replans >= params.maxReplans) {
            int n = 0;
            for (int i = 0; i < d.size(); i++) {
                if (d.get(i) == CellState.REMAINING) {
                    d.set(i, CellState.SKIPPED);
                    n++;
                }
            }
            return new Pick(Kind.GAVE_UP, -1, n);
        }
        replans++;
        plan = null;
        return new Pick(Kind.REPLAN, -1, 0);
    }
}
