package com.areaminer.mining;

import com.areaminer.area.CellState;
import com.areaminer.area.QuarryModel;
import com.areaminer.config.MinerConfig;
import com.areaminer.scanner.CellClassifier;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;

/**
 * Follows ONE target. The shared QuarryModel is the single source of truth: nothing counts as mined
 * until the world shows air, and a block is counted once no matter who noticed it first (this tracker,
 * the layer sweeper, or another player). Every tick the pattern around the target is re-read; once the
 * centre block is gone it waits a few ticks for late server updates, then compares what really
 * disappeared with what the pickaxe profile expected.
 *
 * (1.1.0 only reacted when THIS class saw the air first. The sweeper usually won that race, so the
 * tracker never noticed the block was gone and kept waiting until its timeout.)
 */
public final class MiningTracker {
    public enum Event { NONE, SETTLING, FINISHED, TIMED_OUT, SKIPPED }

    private final QuarryModel model;
    private final CellClassifier classifier;
    private final MiningStats stats;
    private final BlockPos.Mutable scratch = new BlockPos.Mutable();

    private BlockPos centre;
    private int[][] fp;
    private long startTick;
    private int attempts;
    private int settleLeft;
    private boolean requireMining;
    private boolean wasMining;
    private final List<int[]> expectedCells = new ArrayList<>();
    private int lastExpected;
    private int lastBroken;
    private boolean lastWasEvaluated;
    private int abilityMisses;

    public MiningTracker(QuarryModel model, CellClassifier classifier, MiningStats stats) {
        this.model = model;
        this.classifier = classifier;
        this.stats = stats;
    }

    /**
     * @param requireMining true in autonomous mode: the ability is only judged when we actually held the
     *                      attack key on this target (a block that vanished on its own proves nothing)
     */
    public void begin(BlockPos target, int[][] footprint, long tick, boolean requireMining) {
        centre = target;
        fp = footprint;
        startTick = tick;
        attempts = 0;
        settleLeft = -1;
        this.requireMining = requireMining;
        wasMining = false;
        expectedCells.clear();
        for (int[] o : fp) {
            int x = target.getX() + o[0];
            int y = target.getY() + o[1];
            int z = target.getZ() + o[2];
            if (model.q.contains(x, y, z) && model.stateAt(x, y, z) == CellState.REMAINING) {
                expectedCells.add(new int[]{x, y, z});
            }
        }
    }

    /** The autopilot calls this whenever it is really holding the attack key on the target. */
    public void noteMining() {
        wasMining = true;
    }

    public void cancel() {
        centre = null;
    }

    /** Pauses the attempt timer for one tick (walking, turning, or a GUI is open). */
    public void hold() {
        startTick++;
    }

    public boolean active() {
        return centre != null;
    }

    public int attempts() {
        return attempts;
    }

    public int lastExpected() {
        return lastExpected;
    }

    public int lastBroken() {
        return lastBroken;
    }

    /** False when the last target vanished without us mining it, so it says nothing about the ability. */
    public boolean lastWasEvaluated() {
        return lastWasEvaluated;
    }

    public int abilityMisses() {
        return abilityMisses;
    }

    public Event tick(ClientWorld world, long tick, ItemStack tool, MinerConfig cfg) {
        if (centre == null) {
            return Event.NONE;
        }
        // read the pattern from the world; the model counts each removal once
        for (int[] o : fp) {
            int x = centre.getX() + o[0];
            int y = centre.getY() + o[1];
            int z = centre.getZ() + o[2];
            if (!model.q.contains(x, y, z)) {
                continue;
            }
            scratch.set(x, y, z);
            byte now = classifier.classify(world, scratch, tool);
            if (now == CellState.UNKNOWN) {
                continue; // chunk not loaded: never guess
            }
            if (model.observe(x, y, z, now)) {
                stats.record(tick);
            }
        }

        // the centre is gone no matter who noticed first (this tracker, the sweeper, anyone else)
        byte c = model.stateAt(centre.getX(), centre.getY(), centre.getZ());
        boolean centreGone = c == CellState.EMPTY || c == CellState.IGNORED;
        if (centreGone && settleLeft < 0) {
            settleLeft = cfg.settleTicks;
        }
        if (settleLeft >= 0) {
            if (settleLeft == 0) {
                finish();
                return Event.FINISHED;
            }
            settleLeft--;
            return Event.SETTLING;
        }

        if (tick - startTick > (long) cfg.targetTimeoutSeconds * 20L) {
            attempts++;
            if (attempts > cfg.maxRetries) {
                model.observe(centre.getX(), centre.getY(), centre.getZ(), CellState.SKIPPED);
                centre = null;
                return Event.SKIPPED;
            }
            startTick = tick;
            return Event.TIMED_OUT;
        }
        return Event.NONE;
    }

    private void finish() {
        int broken = 0;
        for (int[] e : expectedCells) {
            if (model.stateAt(e[0], e[1], e[2]) == CellState.EMPTY) {
                broken++;
            }
        }
        lastExpected = expectedCells.size();
        lastBroken = broken;
        lastWasEvaluated = !requireMining || wasMining;
        if (lastWasEvaluated && lastExpected > 1) {
            if (broken <= 1) {
                abilityMisses++;
            } else {
                abilityMisses = 0;
            }
        }
        centre = null;
    }
}
