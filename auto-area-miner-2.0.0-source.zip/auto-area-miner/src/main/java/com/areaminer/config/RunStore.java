package com.areaminer.config;

import com.areaminer.area.Quarry;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.util.math.BlockPos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Remembers the last quarry and how many of its blocks were cleared, so a game restart or world reload
 * can continue with the right progress counter instead of starting again from 0%.
 */
public final class RunStore {
    private static final Logger LOG = LoggerFactory.getLogger("AreaMiner");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static final class Saved {
        String dimension;
        int x1, y1, z1, x2, y2, z2;
        long cleared;
    }

    private RunStore() {
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("areaminer").resolve("lastrun.json");
    }

    public static void save(Quarry q, long cleared) {
        if (q == null) {
            return;
        }
        Saved s = new Saved();
        s.dimension = q.dimension;
        s.x1 = q.minX;
        s.y1 = q.minY;
        s.z1 = q.minZ;
        s.x2 = q.maxX;
        s.y2 = q.maxY;
        s.z2 = q.maxZ;
        s.cleared = Math.max(0L, cleared);
        try {
            Files.createDirectories(file().getParent());
            Files.writeString(file(), GSON.toJson(s));
        } catch (IOException e) {
            LOG.warn("Could not save the last run", e);
        }
    }

    private static Saved read() {
        try {
            if (Files.exists(file())) {
                Saved s = GSON.fromJson(Files.readString(file()), Saved.class);
                if (s != null && s.dimension != null) {
                    return s;
                }
            }
        } catch (Exception e) {
            LOG.warn("Could not read the last run", e);
        }
        return null;
    }

    /** The quarry stored last time, or null. */
    public static Quarry loadQuarry() {
        Saved s = read();
        return s == null ? null : new Quarry(new BlockPos(s.x1, s.y1, s.z1), new BlockPos(s.x2, s.y2, s.z2), s.dimension);
    }

    /** Blocks already cleared in a previous session for exactly this quarry, else 0. */
    public static long clearedFor(Quarry q) {
        Saved s = read();
        if (s == null || q == null || !q.dimension.equals(s.dimension)) {
            return 0L;
        }
        boolean same = s.x1 == q.minX && s.y1 == q.minY && s.z1 == q.minZ
                && s.x2 == q.maxX && s.y2 == q.maxY && s.z2 == q.maxZ;
        return same ? s.cleared : 0L;
    }

    public static void delete() {
        try {
            Files.deleteIfExists(file());
        } catch (IOException e) {
            LOG.warn("Could not delete the last run", e);
        }
    }
}
