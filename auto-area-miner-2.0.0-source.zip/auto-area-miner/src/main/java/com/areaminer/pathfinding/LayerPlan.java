package com.areaminer.pathfinding;

import com.areaminer.area.CellState;
import com.areaminer.area.LayerData;
import com.areaminer.area.QuarryModel;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;

/**
 * Plan for ONE layer, built incrementally (a few thousand cells per tick).
 *
 * CENTER_OUT (default): visits the layer's geometric centre first, then concentric square rings
 * outward, each ring clockwise from its north-middle cell. SERPENTINE: the older row-by-row route.
 *
 * Whenever the walk meets a block that no earlier centre will break, it picks the centre (a real,
 * mineable block) whose pattern covers the most still-uncovered blocks. For a normal pickaxe the
 * pattern is one block, so the plan is simply every block in order. For a 3x3 pickaxe it becomes a
 * lattice of centres, anchored on the middle of the layer when CENTER_OUT.
 *
 * Centres whose pattern would break blocks outside the quarry are rejected unless allowOvershoot is
 * on; cells that can only be reached that way become "leftovers".
 */
public final class LayerPlan {
    public enum Order { CENTER_OUT, SERPENTINE }

    private final QuarryModel model;
    private final int layer;
    private final int[][] fp;       // [dx, dy, dz]
    private final int[][] fpLayer;  // dy == 0 entries as [dx, dz]
    private final boolean allowOvershoot;
    private final Order order;
    private final int sx;
    private final int sz;
    private final int ccx;          // centre cell of the layer
    private final int ccz;
    private final int ringMax;
    private final int patW;         // bounding box of the in-layer pattern
    private final int patH;
    private final int anchorX;      // lattice anchor: patterns line up edge to edge from here
    private final int anchorZ;
    private final List<Integer> centres = new ArrayList<>();
    private final List<Integer> leftovers = new ArrayList<>();
    private final BitSet covered;
    private int cursor;             // SERPENTINE position
    private int ring;               // CENTER_OUT position
    private int ringPos;
    private int head;
    private boolean done;

    public LayerPlan(QuarryModel model, int layer, int[][] footprint, boolean allowOvershoot) {
        this(model, layer, footprint, allowOvershoot, Order.SERPENTINE);
    }

    public LayerPlan(QuarryModel model, int layer, int[][] footprint, boolean allowOvershoot, Order order) {
        this.model = model;
        this.layer = layer;
        this.fp = footprint;
        this.allowOvershoot = allowOvershoot;
        this.order = order;
        this.sx = model.q.sizeX();
        this.sz = model.q.sizeZ();
        this.ccx = sx / 2;
        this.ccz = sz / 2;
        this.ringMax = Math.max(Math.max(ccx, sx - 1 - ccx), Math.max(ccz, sz - 1 - ccz));
        this.covered = new BitSet(sx * sz);
        List<int[]> flat = new ArrayList<>();
        for (int[] o : footprint) {
            if (o[1] == 0) {
                flat.add(new int[]{o[0], o[2]});
            }
        }
        if (flat.isEmpty()) {
            flat.add(new int[]{0, 0});
        }
        this.fpLayer = flat.toArray(new int[0][]);
        int minDx = 0;
        int maxDx = 0;
        int minDz = 0;
        int maxDz = 0;
        for (int[] o : fpLayer) {
            minDx = Math.min(minDx, o[0]);
            maxDx = Math.max(maxDx, o[0]);
            minDz = Math.min(minDz, o[1]);
            maxDz = Math.max(maxDz, o[1]);
        }
        this.patW = maxDx - minDx + 1;
        this.patH = maxDz - minDz + 1;
        // centre-out: lattice anchored on the layer's middle; serpentine: on the corner
        this.anchorX = order == Order.CENTER_OUT ? ccx : -minDx;
        this.anchorZ = order == Order.CENTER_OUT ? ccz : -minDz;
    }

    /** 0 when a pattern centred here sits exactly on the lattice, 1 or 2 when it is shifted on one or both axes. */
    private int misalignment(int cx, int cz) {
        return (Math.floorMod(cx - anchorX, patW) == 0 ? 0 : 1) + (Math.floorMod(cz - anchorZ, patH) == 0 ? 0 : 1);
    }

    public boolean isDone() {
        return done;
    }

    public int layer() {
        return layer;
    }

    public int plannedCentres() {
        return centres.size();
    }

    public int[][] footprint() {
        return fp;
    }

    public boolean isMultiBlock() {
        return fp.length > 1;
    }

    /** Index of the layer's centre cell. */
    public int centreIdx() {
        return ccz * sx + ccx;
    }

    public int ringMax() {
        return ringMax;
    }

    /** Chebyshev distance of a cell from the layer centre (0 = the centre itself). */
    public int ringOf(int idx) {
        return Math.max(Math.abs(idx % sx - ccx), Math.abs(idx / sx - ccz));
    }

    /** Next cell in plan order, or -1 for a position outside the layer. Sets done at the end. */
    private int advance() {
        if (order == Order.SERPENTINE) {
            int total = sx * sz;
            if (cursor >= total) {
                done = true;
                return -1;
            }
            int r = cursor / sx;
            int c = cursor % sx;
            cursor++;
            if ((r & 1) == 1) {
                c = sx - 1 - c;
            }
            return r * sx + c;
        }
        if (ring > ringMax) {
            done = true;
            return -1;
        }
        int gx;
        int gz;
        if (ring == 0) {
            gx = ccx;
            gz = ccz;
            ring = 1;
            ringPos = 0;
        } else {
            int per = 8 * ring;
            int p = (ringPos + ring) % per; // start at the north-middle cell of the ring
            if (p < 2 * ring) {
                gx = ccx - ring + p;
                gz = ccz - ring;
            } else if (p < 4 * ring) {
                gx = ccx + ring;
                gz = ccz - ring + (p - 2 * ring);
            } else if (p < 6 * ring) {
                gx = ccx + ring - (p - 4 * ring);
                gz = ccz + ring;
            } else {
                gx = ccx - ring;
                gz = ccz + ring - (p - 6 * ring);
            }
            ringPos++;
            if (ringPos >= per) {
                ring++;
                ringPos = 0;
            }
        }
        if (gx < 0 || gz < 0 || gx >= sx || gz >= sz) {
            return -1;
        }
        return gz * sx + gx;
    }

    /** Processes up to {@code budget} positions. @return true once the whole layer has been planned. */
    public boolean step(int budget) {
        LayerData data = model.layers[layer];
        for (int n = 0; n < budget && !done; n++) {
            int idx = advance();
            if (idx < 0) {
                continue;
            }
            int c = idx % sx;
            int r = idx / sx;
            if (data.get(idx) != CellState.REMAINING || covered.get(idx)) {
                continue;
            }
            int bestCx = -1;
            int bestCz = -1;
            int bestScore = 0;
            int bestAlign = Integer.MAX_VALUE;
            int bestTie = Integer.MAX_VALUE;
            for (int[] o : fpLayer) {
                int cx = c - o[0];
                int cz = r - o[1];
                if (!centreValid(data, cx, cz)) {
                    continue;
                }
                int score = 0;
                for (int[] p : fpLayer) {
                    int x = cx + p[0];
                    int z = cz + p[1];
                    if (x < 0 || z < 0 || x >= sx || z >= sz) {
                        continue;
                    }
                    int j = z * sx + x;
                    if (data.get(j) == CellState.REMAINING && !covered.get(j)) {
                        score++;
                    }
                }
                // equal coverage: prefer centres on the lattice (patterns line up edge to edge, no gaps or
                // pinwheels), then the centre closest to this block
                int align = misalignment(cx, cz);
                int tie = Math.abs(o[0]) + Math.abs(o[1]);
                boolean better = score > bestScore
                        || (score == bestScore && score > 0
                        && (align < bestAlign || (align == bestAlign && tie < bestTie)));
                if (better) {
                    bestScore = score;
                    bestAlign = align;
                    bestTie = tie;
                    bestCx = cx;
                    bestCz = cz;
                }
            }
            if (bestScore == 0) {
                leftovers.add(idx);
                covered.set(idx);
            } else {
                centres.add(bestCz * sx + bestCx);
                for (int[] p : fpLayer) {
                    int x = bestCx + p[0];
                    int z = bestCz + p[1];
                    if (x >= 0 && z >= 0 && x < sx && z < sz && data.get(z * sx + x) == CellState.REMAINING) {
                        covered.set(z * sx + x);
                    }
                }
            }
        }
        return done;
    }

    private boolean centreValid(LayerData data, int cx, int cz) {
        if (cx < 0 || cz < 0 || cx >= sx || cz >= sz) {
            return false;
        }
        if (data.get(cz * sx + cx) != CellState.REMAINING) {
            return false; // the centre is the block we actually mine, so it must exist
        }
        if (allowOvershoot) {
            return true;
        }
        for (int[] o : fp) {
            int x = cx + o[0];
            int z = cz + o[2];
            int l = layer - o[1]; // +dy is up, and layer 0 is the top
            if (x < 0 || z < 0 || x >= sx || z >= sz || l < 0 || l >= model.layers.length) {
                return false;
            }
        }
        return true;
    }

    /** A centre is still worth mining while its own block is still there. */
    private boolean useful(int centreIdx) {
        return model.layers[layer].get(centreIdx) == CellState.REMAINING;
    }

    /** Drops finished centres from the front of the queue. */
    public void pruneHead() {
        while (head < centres.size() && !useful(centres.get(head))) {
            head++;
        }
    }

    /** Up to {@code max} still-useful centres in plan order (cell indices). */
    public List<Integer> upcoming(int max) {
        List<Integer> out = new ArrayList<>();
        for (int i = head; i < centres.size() && out.size() < max; i++) {
            if (useful(centres.get(i))) {
                out.add(centres.get(i));
            }
        }
        return out;
    }

    /** Cells that could not be covered without breaking blocks outside the quarry, and are still present. */
    public int leftoverRemaining() {
        LayerData data = model.layers[layer];
        int n = 0;
        for (int idx : leftovers) {
            if (data.get(idx) == CellState.REMAINING) {
                n++;
            }
        }
        return n;
    }
}
